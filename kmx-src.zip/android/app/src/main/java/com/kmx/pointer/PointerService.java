package com.kmx.pointer;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;

/**
 * Draws a mouse pointer over everything on the TV and moves/clicks it on commands from the phone.
 * UDP port 7656: "P" ping, "M dx dy" move, "C" click, "L" long press, "S dx dy" scroll, "R" centre.
 */
public class PointerService extends AccessibilityService {
    private static final int PORT = 7656;

    private final Handler main = new Handler(Looper.getMainLooper());
    private WindowManager windows;
    private CursorView cursor;
    private WindowManager.LayoutParams params;
    private float x, y;
    private int width, height;
    private float scale = 1f;
    private DatagramSocket socket;
    private volatile boolean running;
    private final Runnable hideCursor = () -> {
        if (cursor != null) cursor.setVisibility(View.GONE);
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        windows = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        windows.getDefaultDisplay().getRealMetrics(dm);
        width = dm.widthPixels;
        height = dm.heightPixels;
        scale = width / 1920f;
        x = width / 2f;
        y = height / 2f;

        cursor = new CursorView(this);
        int size = Math.max(28, Math.round(34 * scale));
        params = new WindowManager.LayoutParams(size, size,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = (int) x;
        params.y = (int) y;
        cursor.setVisibility(View.GONE);
        try {
            windows.addView(cursor, params);
        } catch (Exception e) {
            cursor = null;
        }
        startListening();
    }

    private void startListening() {
        running = true;
        Thread thread = new Thread(() -> {
            try {
                socket = new DatagramSocket(PORT);
                byte[] buffer = new byte[512];
                while (running) {
                    DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                    socket.receive(packet);
                    final String msg = new String(packet.getData(), 0, packet.getLength(), StandardCharsets.UTF_8).trim();
                    if (msg.startsWith("P")) {
                        byte[] ok = "OK".getBytes(StandardCharsets.UTF_8);
                        socket.send(new DatagramPacket(ok, ok.length, packet.getAddress(), packet.getPort()));
                        continue;
                    }
                    main.post(() -> handle(msg));
                }
            } catch (Exception ignored) {
            }
        }, "kmx-pointer");
        thread.setDaemon(true);
        thread.start();
    }

    private void handle(String msg) {
        try {
            String[] parts = msg.split(" ");
            switch (parts[0]) {
                case "M":
                    moveBy(Integer.parseInt(parts[1]) * scale, Integer.parseInt(parts[2]) * scale);
                    break;
                case "C":
                    click(false);
                    break;
                case "L":
                    click(true);
                    break;
                case "S":
                    scrollBy(Integer.parseInt(parts[2]) * scale);
                    break;
                case "R":
                    x = width / 2f;
                    y = height / 2f;
                    showCursor();
                    break;
                default:
                    break;
            }
        } catch (Exception ignored) {
        }
    }

    private void moveBy(float dx, float dy) {
        x = Math.max(0, Math.min(width - 1, x + dx));
        y = Math.max(0, Math.min(height - 1, y + dy));
        showCursor();
    }

    private void showCursor() {
        if (cursor == null) return;
        cursor.setVisibility(View.VISIBLE);
        params.x = (int) x;
        params.y = (int) y;
        try {
            windows.updateViewLayout(cursor, params);
        } catch (Exception ignored) {
        }
        main.removeCallbacks(hideCursor);
        main.postDelayed(hideCursor, 10000);
    }

    private void click(boolean longPress) {
        showCursor();
        if (!longPress && clickNodeUnderPointer()) return;
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, longPress ? 900 : 60))
                .build();
        dispatchGesture(gesture, null, null);
    }

    /** TV apps often ignore touches, so first try "clicking" the smallest clickable item under the pointer. */
    private boolean clickNodeUnderPointer() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo best = null;
        long bestArea = Long.MAX_VALUE;
        Rect r = new Rect();
        ArrayDeque<AccessibilityNodeInfo> stack = new ArrayDeque<>();
        stack.push(root);
        int visited = 0;
        while (!stack.isEmpty() && visited < 3000) {
            visited++;
            AccessibilityNodeInfo n = stack.pop();
            n.getBoundsInScreen(r);
            if (!r.contains((int) x, (int) y) || !n.isVisibleToUser()) continue;
            if (n.isClickable()) {
                long area = (long) r.width() * r.height();
                if (area <= bestArea) {
                    best = n;
                    bestArea = area;
                }
            }
            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo child = n.getChild(i);
                if (child != null) stack.push(child);
            }
        }
        if (best == null) return false;
        if (best.isFocusable()) best.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        return best.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    private void scrollBy(float dy) {
        showCursor();
        float distance = Math.max(-height * 0.6f, Math.min(height * 0.6f, dy));
        float startY = Math.max(10, Math.min(height - 10, y));
        float endY = Math.max(10, Math.min(height - 10, startY + distance));
        if (Math.abs(endY - startY) < 4) return;
        Path path = new Path();
        path.moveTo(x, startY);
        path.lineTo(x, endY);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 160))
                .build();
        dispatchGesture(gesture, null, null);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        running = false;
        if (socket != null) socket.close();
        if (cursor != null) {
            try {
                windows.removeView(cursor);
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }

    /** White arrow with a dark outline; the tip is the top-left corner. */
    static class CursorView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);

        CursorView(Context context) {
            super(context);
            fill.setColor(0xFFFFFFFF);
            edge.setColor(0xFF000000);
            edge.setStyle(Paint.Style.STROKE);
            edge.setStrokeWidth(3f);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float s = getWidth();
            Path p = new Path();
            p.moveTo(2, 2);
            p.lineTo(2, s * 0.86f);
            p.lineTo(s * 0.30f, s * 0.64f);
            p.lineTo(s * 0.50f, s - 2);
            p.lineTo(s * 0.66f, s * 0.92f);
            p.lineTo(s * 0.46f, s * 0.58f);
            p.lineTo(s * 0.82f, s * 0.58f);
            p.close();
            canvas.drawPath(p, fill);
            canvas.drawPath(p, edge);
        }
    }
}
