package com.kmx.pointer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Shows whether the pointer is on, with one button that opens the switch for it. */
public class MainActivity extends Activity {
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(0xFF0D0E10);
        root.setPadding(80, 60, 80, 60);

        TextView title = new TextView(this);
        title.setText("KMX Pointer");
        title.setTextSize(34);
        title.setTextColor(0xFFFF7A1A);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        status = new TextView(this);
        status.setTextSize(20);
        status.setTextColor(Color.WHITE);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 30, 0, 40);
        root.addView(status);

        Button turnOn = new Button(this);
        turnOn.setText("Turn on");
        turnOn.setTextSize(20);
        turnOn.setOnClickListener(v -> openAccessibilitySettings());
        root.addView(turnOn);

        setContentView(root);
        turnOn.requestFocus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isEnabled()) {
            status.setText("The pointer is on. Use Pointer mode in KMX Remote on your iPhone.\nYou can close this screen.");
        } else {
            status.setText("Press Turn on, then choose KMX Pointer in the list and switch it on.\nThe pointer stays on after that, even after the TV restarts.");
        }
    }

    private boolean isEnabled() {
        String list = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return list != null && list.contains(getPackageName() + "/");
    }

    private void openAccessibilitySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Exception ignored) {
            }
        }
    }
}
