import Foundation
import Security

/// The app's TLS client certificate, used to pair with and talk to Google TVs.
enum ClientIdentity {
    static let shared: SecIdentity? = {
        guard let url = Bundle.main.url(forResource: "client", withExtension: "p12"),
              let data = try? Data(contentsOf: url) else { return nil }
        var items: CFArray?
        let status = SecPKCS12Import(data as CFData, [kSecImportExportPassphrase as String: "kmx"] as CFDictionary, &items)
        guard status == errSecSuccess,
              let array = items as? [[String: Any]],
              let first = array.first,
              let identity = first[kSecImportItemIdentity as String] else { return nil }
        return (identity as! SecIdentity)
    }()

    static var certificate: SecCertificate? {
        guard let id = shared else { return nil }
        var cert: SecCertificate?
        SecIdentityCopyCertificate(id, &cert)
        return cert
    }

    /// RSA modulus and exponent of a certificate's public key, without leading zero bytes.
    static func rsaComponents(of cert: SecCertificate) -> (modulus: Data, exponent: Data)? {
        guard let key = SecCertificateCopyKey(cert),
              let ext = SecKeyCopyExternalRepresentation(key, nil) as Data? else { return nil }
        // PKCS#1 RSAPublicKey ::= SEQUENCE { modulus INTEGER, publicExponent INTEGER }
        var bytes = [UInt8](ext)
        var i = 0
        func readLength() -> Int? {
            guard i < bytes.count else { return nil }
            var len = Int(bytes[i]); i += 1
            if len & 0x80 != 0 {
                let n = len & 0x7F
                len = 0
                for _ in 0..<n {
                    guard i < bytes.count else { return nil }
                    len = (len << 8) | Int(bytes[i]); i += 1
                }
            }
            return len
        }
        func readInteger() -> [UInt8]? {
            guard i < bytes.count, bytes[i] == 0x02 else { return nil }
            i += 1
            guard let len = readLength(), i + len <= bytes.count else { return nil }
            var v = Array(bytes[i..<(i + len)])
            i += len
            while v.count > 1 && v.first == 0 { v.removeFirst() }
            return v
        }
        guard bytes.first == 0x30 else { return nil }
        i = 1
        guard readLength() != nil, let mod = readInteger(), let exp = readInteger() else { return nil }
        bytes.removeAll()
        return (Data(mod), Data(exp))
    }
}
