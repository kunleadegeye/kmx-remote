import Foundation

/// Minimal protobuf writer/reader — just enough for the Google TV remote protocol.
struct ProtoWriter {
    private(set) var data = Data()

    static func varint(_ value: UInt64) -> Data {
        var v = value
        var out = Data()
        repeat {
            var byte = UInt8(v & 0x7F)
            v >>= 7
            if v != 0 { byte |= 0x80 }
            out.append(byte)
        } while v != 0
        return out
    }

    mutating func int(_ field: Int, _ value: Int) {
        data.append(ProtoWriter.varint(UInt64(field << 3 | 0)))
        // Negative ints are encoded as 10-byte two's complement, positive as normal.
        data.append(ProtoWriter.varint(UInt64(bitPattern: Int64(value))))
    }

    mutating func bytes(_ field: Int, _ value: Data) {
        data.append(ProtoWriter.varint(UInt64(field << 3 | 2)))
        data.append(ProtoWriter.varint(UInt64(value.count)))
        data.append(value)
    }

    mutating func string(_ field: Int, _ value: String) {
        bytes(field, Data(value.utf8))
    }

    mutating func message(_ field: Int, _ build: (inout ProtoWriter) -> Void) {
        var sub = ProtoWriter()
        build(&sub)
        bytes(field, sub.data)
    }

    /// Length-delimited frame as used on the wire (varint size + payload).
    var framed: Data {
        var out = ProtoWriter.varint(UInt64(data.count))
        out.append(data)
        return out
    }
}

/// Parsed protobuf message: field number → list of values (varint or bytes).
struct ProtoMessage {
    enum Value {
        case varint(UInt64)
        case bytes(Data)
    }

    private(set) var fields: [Int: [Value]] = [:]

    init?(_ data: Data) {
        var i = data.startIndex
        func readVarint() -> UInt64? {
            var result: UInt64 = 0
            var shift: UInt64 = 0
            while i < data.endIndex {
                let b = data[i]
                i = data.index(after: i)
                result |= UInt64(b & 0x7F) << shift
                if b & 0x80 == 0 { return result }
                shift += 7
                if shift > 63 { return nil }
            }
            return nil
        }
        while i < data.endIndex {
            guard let key = readVarint() else { return nil }
            let field = Int(key >> 3)
            let wire = key & 7
            switch wire {
            case 0:
                guard let v = readVarint() else { return nil }
                fields[field, default: []].append(.varint(v))
            case 2:
                guard let len = readVarint() else { return nil }
                let end = data.index(i, offsetBy: Int(len), limitedBy: data.endIndex) ?? data.endIndex
                if data.distance(from: i, to: end) != Int(len) { return nil }
                fields[field, default: []].append(.bytes(Data(data[i..<end])))
                i = end
            case 1:
                guard data.distance(from: i, to: data.endIndex) >= 8 else { return nil }
                i = data.index(i, offsetBy: 8)
            case 5:
                guard data.distance(from: i, to: data.endIndex) >= 4 else { return nil }
                i = data.index(i, offsetBy: 4)
            default:
                return nil
            }
        }
    }

    func has(_ field: Int) -> Bool { fields[field] != nil }

    func int(_ field: Int) -> Int {
        if case .varint(let v)? = fields[field]?.first { return Int(truncatingIfNeeded: Int64(bitPattern: v)) }
        return 0
    }

    func data(_ field: Int) -> Data? {
        if case .bytes(let d)? = fields[field]?.first { return d }
        return nil
    }

    func string(_ field: Int) -> String {
        guard let d = data(field) else { return "" }
        return String(decoding: d, as: UTF8.self)
    }

    func message(_ field: Int) -> ProtoMessage? {
        guard let d = data(field) else { return fields[field] != nil ? ProtoMessage(Data()) : nil }
        return ProtoMessage(d)
    }
}

/// Splits a TCP stream into varint-length-prefixed messages.
struct FrameBuffer {
    private var buffer = Data()

    mutating func append(_ data: Data) -> [Data] {
        buffer.append(data)
        var out: [Data] = []
        while true {
            var len: UInt64 = 0
            var shift: UInt64 = 0
            var idx = buffer.startIndex
            var complete = false
            while idx < buffer.endIndex {
                let b = buffer[idx]
                idx = buffer.index(after: idx)
                len |= UInt64(b & 0x7F) << shift
                if b & 0x80 == 0 { complete = true; break }
                shift += 7
            }
            guard complete else { break }
            guard buffer.distance(from: idx, to: buffer.endIndex) >= Int(len) else { break }
            let end = buffer.index(idx, offsetBy: Int(len))
            out.append(Data(buffer[idx..<end]))
            buffer = Data(buffer[end...])
        }
        return out
    }
}
