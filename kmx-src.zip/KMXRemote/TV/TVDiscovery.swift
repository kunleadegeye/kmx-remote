import Foundation
import Network

/// Finds Google / Android TVs on the home Wi‑Fi and resolves their IP addresses.
final class TVDiscovery: ObservableObject {
    struct FoundTV: Identifiable, Hashable {
        let id: String
        let name: String
        var host: String?
    }

    @Published private(set) var tvs: [FoundTV] = []
    @Published private(set) var searching = false
    private var browser: NWBrowser?
    private var resolvers: [String: NWConnection] = [:]

    func start() {
        stop()
        searching = true
        let params = NWParameters()
        params.includePeerToPeer = false
        let browser = NWBrowser(for: .bonjour(type: "_androidtvremote2._tcp", domain: nil), using: params)
        self.browser = browser
        browser.browseResultsChangedHandler = { [weak self] results, _ in
            DispatchQueue.main.async { self?.update(results) }
        }
        browser.stateUpdateHandler = { [weak self] state in
            if case .failed = state { DispatchQueue.main.async { self?.searching = false } }
        }
        browser.start(queue: .main)
    }

    func stop() {
        browser?.cancel()
        browser = nil
        resolvers.values.forEach { $0.cancel() }
        resolvers.removeAll()
        searching = false
    }

    private func update(_ results: Set<NWBrowser.Result>) {
        for result in results {
            guard case let .service(name, _, _, _) = result.endpoint else { continue }
            if tvs.contains(where: { $0.id == name }) { continue }
            tvs.append(FoundTV(id: name, name: name, host: nil))
            resolve(name: name, endpoint: result.endpoint)
        }
    }

    /// Opens a throwaway TCP connection to learn the TV's IP address.
    private func resolve(name: String, endpoint: NWEndpoint) {
        let params = NWParameters.tcp
        if let ip = params.defaultProtocolStack.internetProtocol as? NWProtocolIP.Options {
            ip.version = .v4
        }
        let conn = NWConnection(to: endpoint, using: params)
        resolvers[name] = conn
        conn.stateUpdateHandler = { [weak self, weak conn] state in
            guard let self, let conn else { return }
            if case .ready = state {
                if case let .hostPort(host, _)? = conn.currentPath?.remoteEndpoint {
                    var text = "\(host)"
                    if let pct = text.firstIndex(of: "%") { text = String(text[..<pct]) }
                    DispatchQueue.main.async {
                        if let i = self.tvs.firstIndex(where: { $0.id == name }) { self.tvs[i].host = text }
                    }
                }
                conn.cancel()
            } else if case .failed = state {
                conn.cancel()
            }
        }
        conn.start(queue: .main)
    }
}
