import Foundation
import Network
import Security

/// A TLS connection (with our client certificate) that exchanges length-prefixed protobuf messages.
final class TLSLink {
    enum Event {
        case ready
        case message(ProtoMessage)
        case closed(Error?)
    }

    private let connection: NWConnection
    private let queue = DispatchQueue(label: "kmx.tls")
    private var frames = FrameBuffer()
    private(set) var serverCertificate: SecCertificate?
    var onEvent: ((Event) -> Void)?
    private var finished = false

    init(host: String, port: UInt16) {
        let tls = NWProtocolTLS.Options()
        let sec = tls.securityProtocolOptions
        if let identity = ClientIdentity.shared, let secId = sec_identity_create(identity) {
            sec_protocol_options_set_local_identity(sec, secId)
        }
        sec_protocol_options_set_min_tls_protocol_version(sec, .TLSv12)
        let captured = CertBox()
        sec_protocol_options_set_verify_block(sec, { _, trust, complete in
            let secTrust = sec_trust_copy_ref(trust).takeRetainedValue()
            if let chain = SecTrustCopyCertificateChain(secTrust) as? [SecCertificate], let leaf = chain.first {
                captured.cert = leaf
            }
            complete(true) // TVs use self-signed certificates.
        }, DispatchQueue(label: "kmx.tls.verify"))
        let tcp = NWProtocolTCP.Options()
        tcp.noDelay = true
        tcp.connectionTimeout = 6
        let params = NWParameters(tls: tls, tcp: tcp)
        connection = NWConnection(host: NWEndpoint.Host(host), port: NWEndpoint.Port(rawValue: port)!, using: params)
        connection.stateUpdateHandler = { [weak self] state in
            guard let self else { return }
            switch state {
            case .ready:
                self.serverCertificate = captured.cert
                self.emit(.ready)
                self.receive()
            case .failed(let err):
                self.finish(err)
            case .waiting(let err):
                self.finish(err)
            case .cancelled:
                self.finish(nil)
            default:
                break
            }
        }
    }

    func start() { connection.start(queue: queue) }

    func close() { connection.cancel() }

    func send(_ writer: ProtoWriter) {
        connection.send(content: writer.framed, completion: .contentProcessed { _ in })
    }

    private func emit(_ e: Event) {
        DispatchQueue.main.async { self.onEvent?(e) }
    }

    private func finish(_ err: Error?) {
        guard !finished else { return }
        finished = true
        connection.cancel()
        emit(.closed(err))
    }

    private func receive() {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 65536) { [weak self] data, _, isComplete, error in
            guard let self else { return }
            if let data, !data.isEmpty {
                for frame in self.frames.append(data) {
                    if let msg = ProtoMessage(frame) { self.emit(.message(msg)) }
                }
            }
            if let error { self.finish(error); return }
            if isComplete { self.finish(nil); return }
            self.receive()
        }
    }
}

final class CertBox { var cert: SecCertificate? }
