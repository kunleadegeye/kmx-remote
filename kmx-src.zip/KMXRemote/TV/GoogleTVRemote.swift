import Foundation
import Combine
import Network

/// Android key codes used by the TV remote.
enum TVKey: Int {
    case home = 3, back = 4
    case up = 19, down = 20, left = 21, right = 22, center = 23
    case volumeUp = 24, volumeDown = 25, power = 26
    case enter = 66, del = 67, menu = 82, search = 84
    case playPause = 85, stop = 86, next = 87, previous = 88, rewind = 89, fastForward = 90
    case mute = 164, info = 165, channelUp = 166, channelDown = 167
    case guide = 172, settings = 176, input = 178
    case assist = 219
}

/// Live connection to one Google TV (port 6466).
final class GoogleTVRemote: ObservableObject {
    enum Status: Equatable {
        case disconnected, connecting, connected
        case needsPairing
        case unreachable(String)
    }

    @Published private(set) var status: Status = .disconnected
    @Published private(set) var currentApp: String = ""
    @Published private(set) var volume: (level: Int, max: Int, muted: Bool)? = nil
    @Published private(set) var voiceSessionActive = false
    /// True once the TV has told us a text box is open.
    @Published private(set) var textFieldOpen = false

    let host: String
    private var link: TLSLink?
    private var imeCounter = 0
    private var imeFieldCounter = 0
    private var features = 0
    private var retryWork: DispatchWorkItem?
    private var wantsConnection = false
    private var voiceBeginHandler: ((Int?) -> Void)?
    private var voiceSessionId: Int?
    /// Keys pressed while (re)connecting are sent as soon as the TV is ready, instead of being lost.
    private var pendingKeys: [(key: Int, direction: Int, at: Date)] = []

    // Feature flags: PING | KEY | IME | VOICE | POWER | VOLUME | APP_LINK
    private let requestedFeatures = 1 | 2 | 4 | 8 | 32 | 64 | 512

    init(host: String) { self.host = host }

    func connect() {
        wantsConnection = true
        guard link == nil else { return }
        status = .connecting
        let link = TLSLink(host: host, port: 6466)
        self.link = link
        link.onEvent = { [weak self, weak link] event in
            guard let self, let link, self.link === link else { return }
            switch event {
            case .ready:
                break // The TV speaks first with remote_configure.
            case .message(let msg):
                self.handle(msg, link: link)
            case .closed(let err):
                self.link = nil
                self.voiceSessionId = nil
                self.voiceSessionActive = false
                if self.status == .connecting {
                    // A TV that doesn't know our certificate rejects the secure handshake → needs pairing.
                    if let nwErr = err as? NWError, case .tls = nwErr {
                        self.status = .needsPairing
                        return
                    }
                    if err == nil && self.features == 0 {
                        self.status = .needsPairing
                        return
                    }
                    self.status = .unreachable("Can't reach the TV. Is it on and on this Wi‑Fi?")
                } else {
                    self.status = .disconnected
                }
                self.scheduleRetry()
            }
        }
        link.start()
    }

    func disconnect() {
        wantsConnection = false
        retryWork?.cancel()
        link?.close()
        link = nil
        pendingKeys.removeAll()
        status = .disconnected
    }

    private func scheduleRetry() {
        guard wantsConnection else { return }
        retryWork?.cancel()
        let work = DispatchWorkItem { [weak self] in
            guard let self, self.wantsConnection, self.link == nil, self.status != .needsPairing else { return }
            self.connect()
        }
        retryWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: work)
    }

    private func markConnected() {
        guard status != .connected else { return }
        status = .connected
        // Send anything pressed in the last few seconds while we were connecting.
        let keys = pendingKeys.filter { Date().timeIntervalSince($0.at) < 4 }
        pendingKeys.removeAll()
        for k in keys { send(key: k.key, direction: k.direction) }
    }

    private func handle(_ msg: ProtoMessage, link: TLSLink) {
        if let cfg = msg.message(1) { // remote_configure
            features = requestedFeatures & (cfg.int(1) == 0 ? requestedFeatures : cfg.int(1))
            var w = ProtoWriter()
            w.message(1) { c in
                c.int(1, features)
                c.message(2) { info in
                    info.string(1, "iPhone")
                    info.string(2, "KMX")
                    info.int(3, 1)
                    info.string(4, "1")
                    info.string(5, "atvremote")
                    info.string(6, "1.0.0")
                }
            }
            link.send(w)
        } else if msg.has(2) { // remote_set_active
            var w = ProtoWriter()
            w.message(2) { a in a.int(1, features) }
            link.send(w)
        } else if let ping = msg.message(8) { // ping
            var w = ProtoWriter()
            w.message(9) { r in r.int(1, ping.int(1)) }
            link.send(w)
        } else if msg.has(40) { // remote_start
            markConnected()
        } else if let ime = msg.message(20) { // ime key inject → current app
            if let app = ime.message(1) { currentApp = app.string(12) }
        } else if let batch = msg.message(21) {
            imeCounter = batch.int(1)
            imeFieldCounter = batch.int(2)
            textFieldOpen = true
        } else if let show = msg.message(22) {
            if let field = show.message(2) { imeFieldCounter = field.int(1) }
            textFieldOpen = true
        } else if let vol = msg.message(50) {
            volume = (vol.int(7), vol.int(6), vol.int(8) != 0)
        } else if let begin = msg.message(30) { // voice begin from TV
            voiceBeginHandler?(begin.int(1))
            voiceBeginHandler = nil
        }
        if status == .connecting, msg.has(2) || msg.has(8) { markConnected() }
    }

    // MARK: Commands

    func press(_ key: TVKey) { send(key: key.rawValue, direction: 3) }

    func longPress(_ key: TVKey, down: Bool) { send(key: key.rawValue, direction: down ? 1 : 2) }

    private func send(key: Int, direction: Int) {
        guard let link, status == .connected else {
            if pendingKeys.count < 8 { pendingKeys.append((key, direction, Date())) }
            connect()
            return
        }
        var w = ProtoWriter()
        w.message(10) { k in k.int(1, key); k.int(2, direction) }
        link.send(w)
    }

    /// Adds text at the cursor in the TV's focused text box (the TV appends whatever we send).
    func insertText(_ text: String) {
        guard let link, !text.isEmpty else { return }
        var w = ProtoWriter()
        w.message(21) { b in
            b.int(1, imeCounter)
            b.int(2, imeFieldCounter)
            b.message(3) { e in
                e.int(1, 1)
                e.message(2) { o in
                    o.int(1, text.count - 1)
                    o.int(2, text.count - 1)
                    o.string(3, text)
                }
            }
        }
        link.send(w)
    }

    /// Deletes characters before the cursor on the TV.
    func deleteBackward(_ count: Int) {
        guard count > 0 else { return }
        for _ in 0..<min(count, 200) { press(.del) }
    }

    func openApp(_ link: String) {
        guard let conn = self.link else { connect(); return }
        var w = ProtoWriter()
        w.message(90) { a in a.string(1, link) }
        conn.send(w)
    }

    // MARK: Voice

    /// Starts a voice session on the TV. Calls back with true when audio can be streamed.
    func beginVoice(_ completion: @escaping (Bool) -> Void) {
        guard link != nil, status == .connected, features & 8 != 0 else { completion(false); return }
        voiceBeginHandler = { [weak self] session in
            guard let self, let session, let link = self.link else { completion(false); return }
            self.voiceSessionId = session
            self.voiceSessionActive = true
            var w = ProtoWriter()
            w.message(30) { b in b.int(1, session) }
            link.send(w)
            completion(true)
        }
        press(.search)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { [weak self] in
            if let handler = self?.voiceBeginHandler {
                self?.voiceBeginHandler = nil
                handler(nil)
            }
        }
    }

    /// 16-bit PCM, mono, 8 kHz.
    func sendVoice(_ pcm: Data) {
        guard let link, let session = voiceSessionId else { return }
        var offset = 0
        while offset < pcm.count {
            var chunk = pcm.subdata(in: offset..<min(offset + 20 * 1024, pcm.count))
            if chunk.count < 8 * 1024 { chunk.append(Data(count: 8 * 1024 - chunk.count)) }
            var w = ProtoWriter()
            w.message(31) { p in p.int(1, session); p.bytes(2, chunk) }
            link.send(w)
            offset += 20 * 1024
        }
    }

    func endVoice() {
        voiceBeginHandler = nil
        guard let session = voiceSessionId else { return }
        if let link {
            var w = ProtoWriter()
            w.message(32) { e in e.int(1, session) }
            link.send(w)
        }
        voiceSessionId = nil
        voiceSessionActive = false
    }
}
