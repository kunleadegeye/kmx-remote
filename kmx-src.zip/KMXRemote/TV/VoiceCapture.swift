import Foundation
import AVFoundation
import Speech

/// Records the microphone and delivers 16-bit, 8 kHz, mono PCM — the format Google TV voice search expects.
final class VoiceCapture {
    private let engine = AVAudioEngine()
    private var converter: AVAudioConverter?
    private let outFormat = AVAudioFormat(commonFormat: .pcmFormatInt16, sampleRate: 8000, channels: 1, interleaved: true)!
    private var pending = Data()
    private var running = false
    var onChunk: ((Data) -> Void)?
    var onLevel: ((Float) -> Void)?
    /// Raw microphone audio, for on-phone speech recognition. Called on the audio thread.
    var onBuffer: ((AVAudioPCMBuffer) -> Void)?

    static func requestPermission(_ done: @escaping (Bool) -> Void) {
        AVAudioSession.sharedInstance().requestRecordPermission { ok in
            DispatchQueue.main.async { done(ok) }
        }
    }

    func start() throws {
        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.playAndRecord, mode: .measurement, options: [.duckOthers, .defaultToSpeaker])
        try session.setActive(true)
        let input = engine.inputNode
        let inFormat = input.outputFormat(forBus: 0)
        converter = AVAudioConverter(from: inFormat, to: outFormat)
        pending.removeAll()
        input.removeTap(onBus: 0)
        input.installTap(onBus: 0, bufferSize: 2048, format: inFormat) { [weak self] buffer, _ in
            self?.onBuffer?(buffer)
            self?.process(buffer)
        }
        engine.prepare()
        try engine.start()
        running = true
    }

    func stop() {
        guard running else { return }
        running = false
        engine.inputNode.removeTap(onBus: 0)
        engine.stop()
        if !pending.isEmpty {
            let rest = pending
            pending.removeAll()
            DispatchQueue.main.async { self.onChunk?(rest) }
        }
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    private func process(_ buffer: AVAudioPCMBuffer) {
        guard let converter else { return }
        let ratio = outFormat.sampleRate / buffer.format.sampleRate
        let capacity = AVAudioFrameCount(Double(buffer.frameLength) * ratio) + 32
        guard let out = AVAudioPCMBuffer(pcmFormat: outFormat, frameCapacity: capacity) else { return }
        var supplied = false
        var error: NSError?
        converter.convert(to: out, error: &error) { _, status in
            if supplied { status.pointee = .noDataNow; return nil }
            supplied = true
            status.pointee = .haveData
            return buffer
        }
        guard error == nil, let ptr = out.int16ChannelData?[0] else { return }
        let count = Int(out.frameLength)
        var peak: Int16 = 0
        for i in 0..<count { peak = max(peak, abs(ptr[i] == Int16.min ? Int16.max : ptr[i])) }
        let level = Float(peak) / Float(Int16.max)
        pending.append(Data(bytes: ptr, count: count * 2))
        if pending.count >= 8 * 1024 {
            let chunk = pending
            pending.removeAll()
            DispatchQueue.main.async {
                self.onChunk?(chunk)
            }
        }
        DispatchQueue.main.async { self.onLevel?(level) }
    }
}

/// Turns speech into text on the phone, so voice still works when the TV won't take audio.
final class SpeechTranscriber {
    private let recognizer: SFSpeechRecognizer? = SFSpeechRecognizer(locale: Locale.current) ?? SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    var onText: ((String) -> Void)?

    static func requestPermission(_ done: @escaping (Bool) -> Void) {
        SFSpeechRecognizer.requestAuthorization { status in
            DispatchQueue.main.async { done(status == .authorized) }
        }
    }

    var isAvailable: Bool {
        SFSpeechRecognizer.authorizationStatus() == .authorized && (recognizer?.isAvailable ?? false)
    }

    func start() {
        guard isAvailable, let recognizer else { return }
        let req = SFSpeechAudioBufferRecognitionRequest()
        req.shouldReportPartialResults = true
        request = req
        task = recognizer.recognitionTask(with: req) { [weak self] result, _ in
            guard let result else { return }
            let text = result.bestTranscription.formattedString
            DispatchQueue.main.async { self?.onText?(text) }
        }
    }

    func append(_ buffer: AVAudioPCMBuffer) {
        request?.append(buffer)
    }

    /// Stops listening but lets the final words come through.
    func stop() {
        request?.endAudio()
        request = nil
    }

    func cancel() {
        request?.endAudio()
        request = nil
        task?.cancel()
        task = nil
    }
}
