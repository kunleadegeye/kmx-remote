import Foundation
import AVFoundation

/// Records the microphone and delivers 16-bit, 8 kHz, mono PCM — the format Google TV voice search expects.
final class VoiceCapture {
    private let engine = AVAudioEngine()
    private var converter: AVAudioConverter?
    private let outFormat = AVAudioFormat(commonFormat: .pcmFormatInt16, sampleRate: 8000, channels: 1, interleaved: true)!
    private var pending = Data()
    var onChunk: ((Data) -> Void)?
    var onLevel: ((Float) -> Void)?

    static func requestPermission(_ done: @escaping (Bool) -> Void) {
        AVAudioSession.sharedInstance().requestRecordPermission { ok in
            DispatchQueue.main.async { done(ok) }
        }
    }

    func start() throws {
        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.playAndRecord, mode: .measurement, options: [.duckOthers, .defaultToSpeaker])
        try session.setActive(true)
        let input = engine.inputNode
        let inFormat = input.outputFormat(forBus: 0)
        converter = AVAudioConverter(from: inFormat, to: outFormat)
        pending.removeAll()
        input.removeTap(onBus: 0)
        input.installTap(onBus: 0, bufferSize: 2048, format: inFormat) { [weak self] buffer, _ in
            self?.process(buffer)
        }
        engine.prepare()
        try engine.start()
    }

    func stop() {
        engine.inputNode.removeTap(onBus: 0)
        engine.stop()
        if !pending.isEmpty {
            let rest = pending
            pending.removeAll()
            DispatchQueue.main.async { self.onChunk?(rest) }
        }
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    private func process(_ buffer: AVAudioPCMBuffer) {
        guard let converter else { return }
        let ratio = outFormat.sampleRate / buffer.format.sampleRate
        let capacity = AVAudioFrameCount(Double(buffer.frameLength) * ratio) + 32
        guard let out = AVAudioPCMBuffer(pcmFormat: outFormat, frameCapacity: capacity) else { return }
        var supplied = false
        var error: NSError?
        converter.convert(to: out, error: &error) { _, status in
            if supplied { status.pointee = .noDataNow; return nil }
            supplied = true
            status.pointee = .haveData
            return buffer
        }
        guard error == nil, let ptr = out.int16ChannelData?[0] else { return }
        let count = Int(out.frameLength)
        var peak: Int16 = 0
        for i in 0..<count { peak = max(peak, abs(ptr[i] == Int16.min ? Int16.max : ptr[i])) }
        let level = Float(peak) / Float(Int16.max)
        pending.append(Data(bytes: ptr, count: count * 2))
        if pending.count >= 8 * 1024 {
            let chunk = pending
            pending.removeAll()
            DispatchQueue.main.async {
                self.onChunk?(chunk)
            }
        }
        DispatchQueue.main.async { self.onLevel?(level) }
    }
}
