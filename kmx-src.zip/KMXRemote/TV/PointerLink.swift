import Foundation
import Network
import CoreMotion
import Combine

/// Talks to the KMX Pointer helper app on the TV over UDP port 7656.
/// Messages: "P" ping (TV answers "OK"), "M dx dy" move, "C" click, "L" long press, "S dx dy" scroll, "R" centre.
final class PointerLink: ObservableObject {
    @Published private(set) var helperFound = false

    let host: String
    private var conn: NWConnection?
    private var pingTimer: Timer?
    private var lastReply = Date.distantPast
    private var accX = 0.0, accY = 0.0
    private var scrollAcc = 0.0

    init(host: String) { self.host = host }

    func start() {
        if conn == nil {
            guard let port = NWEndpoint.Port(rawValue: 7656) else { return }
            let c = NWConnection(host: NWEndpoint.Host(host), port: port, using: .udp)
            conn = c
            c.start(queue: .main)
            receive(c)
        }
        if pingTimer == nil {
            pingTimer = Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) { [weak self] _ in self?.refresh() }
        }
        refresh()
    }

    func stop() {
        pingTimer?.invalidate()
        pingTimer = nil
        conn?.cancel()
        conn = nil
    }

    /// Asks the helper if it's there.
    func refresh() {
        send("P")
        if helperFound, Date().timeIntervalSince(lastReply) > 6 { helperFound = false }
    }

    private func receive(_ c: NWConnection) {
        c.receiveMessage { [weak self] data, _, _, error in
            guard let self, self.conn === c else { return }
            if let data, String(decoding: data, as: UTF8.self).hasPrefix("OK") {
                self.lastReply = Date()
                if !self.helperFound { self.helperFound = true }
            }
            if error == nil { self.receive(c) }
        }
    }

    private func send(_ s: String) {
        conn?.send(content: Data(s.utf8), completion: .contentProcessed { _ in })
    }

    /// Moves the pointer by TV pixels (1920-wide screen units).
    func move(dx: Double, dy: Double) {
        accX += dx
        accY += dy
        let x = Int(accX), y = Int(accY)
        guard x != 0 || y != 0 else { return }
        accX -= Double(x)
        accY -= Double(y)
        send("M \(x) \(y)")
    }

    /// Positive dy drags the page down, like a finger on a touch screen.
    func scroll(dy: Double) {
        scrollAcc += dy
        guard abs(scrollAcc) >= 24 else { return }
        let y = Int(scrollAcc)
        scrollAcc = 0
        send("S 0 \(y)")
    }

    func click() { send("C") }
    func longClick() { send("L") }
    func center() { send("R") }
}

/// Serves the TV helper app to the TV's Downloader app over your Wi‑Fi (one-time setup).
final class HelperServer: ObservableObject {
    @Published private(set) var address: String?
    @Published private(set) var problem: String?
    private var listener: NWListener?

    func start() {
        guard listener == nil else { return }
        guard let url = Bundle.main.url(forResource: "KMXPointer", withExtension: "apk"),
              let apk = try? Data(contentsOf: url) else {
            problem = "The helper isn't included in this version of the app."
            return
        }
        guard let ip = HelperServer.wifiAddress() else {
            problem = "Connect this iPhone to the same Wi‑Fi as the TV, then come back here."
            return
        }
        guard let port = NWEndpoint.Port(rawValue: 8080), let l = try? NWListener(using: .tcp, on: port) else {
            problem = "Couldn't start the download. Close and reopen the app, then try again."
            return
        }
        listener = l
        l.newConnectionHandler = { c in
            c.start(queue: .global())
            c.receive(minimumIncompleteLength: 1, maximumLength: 16384) { _, _, _, _ in
                let head = "HTTP/1.1 200 OK\r\nContent-Type: application/vnd.android.package-archive\r\nContent-Disposition: attachment; filename=\"KMXPointer.apk\"\r\nContent-Length: \(apk.count)\r\nConnection: close\r\n\r\n"
                var out = Data(head.utf8)
                out.append(apk)
                c.send(content: out, completion: .contentProcessed { _ in
                    DispatchQueue.global().asyncAfter(deadline: .now() + 2) { c.cancel() }
                })
            }
        }
        l.stateUpdateHandler = { [weak self] state in
            if case .failed = state {
                DispatchQueue.main.async {
                    self?.address = nil
                    self?.problem = "Couldn't start the download. Close and reopen the app, then try again."
                }
            }
        }
        l.start(queue: .main)
        problem = nil
        address = "http://\(ip):8080/kmx.apk"
    }

    func stop() {
        listener?.cancel()
        listener = nil
    }

    static func wifiAddress() -> String? {
        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&ifaddr) == 0, let first = ifaddr else { return nil }
        defer { freeifaddrs(ifaddr) }
        for ptr in sequence(first: first, next: { $0.pointee.ifa_next }) {
            let ifa = ptr.pointee
            guard let addr = ifa.ifa_addr, addr.pointee.sa_family == UInt8(AF_INET) else { continue }
            guard String(cString: ifa.ifa_name) == "en0" else { continue }
            var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            if getnameinfo(addr, socklen_t(addr.pointee.sa_len), &host, socklen_t(host.count), nil, 0, NI_NUMERICHOST) == 0 {
                return String(cString: host)
            }
        }
        return nil
    }
}

/// Air mouse: turns the phone's movement into pointer movement.
final class MotionPointer {
    private let manager = CMMotionManager()
    var sensitivity = 1.0
    var onMove: ((Double, Double) -> Void)?
    private var smoothX = 0.0, smoothY = 0.0

    var isAvailable: Bool { manager.isDeviceMotionAvailable }

    func start() {
        guard manager.isDeviceMotionAvailable, !manager.isDeviceMotionActive else { return }
        smoothX = 0
        smoothY = 0
        manager.deviceMotionUpdateInterval = 1.0 / 60.0
        manager.startDeviceMotionUpdates(to: .main) { [weak self] motion, _ in
            guard let self, let motion else { return }
            let r = motion.rotationRate
            let g = motion.gravity
            // Turning left/right = spin around the vertical (gravity) axis. Tilting up/down = spin around the phone's side-to-side axis.
            var yaw = r.x * g.x + r.y * g.y + r.z * g.z
            var pitch = r.x
            if abs(yaw) < 0.025 { yaw = 0 }
            if abs(pitch) < 0.025 { pitch = 0 }
            self.smoothX = self.smoothX * 0.35 + yaw * 0.65
            self.smoothY = self.smoothY * 0.35 + pitch * 0.65
            let k = 1100.0 / 60.0 * self.sensitivity
            self.onMove?(self.smoothX * k, -self.smoothY * k)
        }
    }

    func stop() {
        manager.stopDeviceMotionUpdates()
    }
}
