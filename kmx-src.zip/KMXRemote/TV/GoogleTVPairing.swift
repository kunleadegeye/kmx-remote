import Foundation
import CryptoKit
import Security

/// Pairs the app with a Google TV (port 6467). The TV shows a 6-character code; the user types it in.
final class GoogleTVPairing: ObservableObject {
    enum Stage: Equatable {
        case idle
        case connecting
        case waitingForCode
        case verifying
        case paired
        case failed(String)
    }

    @Published var stage: Stage = .idle
    private var link: TLSLink?
    let host: String

    init(host: String) { self.host = host }

    private func base() -> ProtoWriter {
        var w = ProtoWriter()
        w.int(1, 2)      // protocol_version
        w.int(2, 200)    // status OK
        return w
    }

    func start() {
        stage = .connecting
        link?.close()
        let link = TLSLink(host: host, port: 6467)
        self.link = link
        link.onEvent = { [weak self] event in
            guard let self else { return }
            switch event {
            case .ready:
                var w = self.base()
                w.message(10) { req in
                    req.string(1, "atvremote")
                    req.string(2, "KMX Remote")
                }
                link.send(w)
            case .message(let msg):
                self.handle(msg)
            case .closed(let err):
                if self.stage != .paired {
                    if case .failed = self.stage { return }
                    self.stage = .failed(err.map { "Couldn't reach the TV (\($0.localizedDescription)). Make sure it is on and on the same Wi‑Fi." } ?? "The TV closed the connection. Try again.")
                }
            }
        }
        link.start()
    }

    private func handle(_ msg: ProtoMessage) {
        guard let link else { return }
        if msg.int(2) != 200 {
            stage = .failed(msg.int(2) == 402 ? "That code didn't match. Try again." : "The TV refused pairing (error \(msg.int(2))).")
            link.close()
            return
        }
        if msg.has(11) { // pairing_request_ack → send options
            var w = base()
            w.message(20) { opt in
                opt.message(1) { enc in enc.int(1, 3); enc.int(2, 6) } // hexadecimal, 6 symbols
                opt.int(3, 1) // preferred role: input
            }
            link.send(w)
        } else if msg.has(20) { // options → send configuration
            var w = base()
            w.message(30) { cfg in
                cfg.message(1) { enc in enc.int(1, 3); enc.int(2, 6) }
                cfg.int(2, 1)
            }
            link.send(w)
        } else if msg.has(31) { // configuration_ack → code is on the TV now
            stage = .waitingForCode
        } else if msg.has(41) { // secret_ack
            stage = .paired
            link.close()
        }
    }

    func submit(code raw: String) {
        let code = raw.trimmingCharacters(in: .whitespaces).uppercased()
        guard code.count == 6, let codeBytes = Data(hex: code) else {
            stage = .failed("The code has 6 characters (numbers and letters A–F).")
            return
        }
        guard let link,
              let clientCert = ClientIdentity.certificate,
              let serverCert = link.serverCertificate,
              let client = ClientIdentity.rsaComponents(of: clientCert),
              let server = ClientIdentity.rsaComponents(of: serverCert) else {
            stage = .failed("Couldn't read the TV's security certificate. Try again.")
            return
        }
        var hasher = SHA256()
        hasher.update(data: client.modulus)
        hasher.update(data: client.exponent)
        hasher.update(data: server.modulus)
        hasher.update(data: server.exponent)
        hasher.update(data: codeBytes.dropFirst())
        let digest = Data(hasher.finalize())
        if digest.first != codeBytes.first {
            stage = .failed("That code didn't match what the TV shows. Check it and try again.")
            return
        }
        stage = .verifying
        var w = base()
        w.message(40) { s in s.bytes(1, digest) }
        link.send(w)
    }

    func cancel() { link?.close() }
}

extension Data {
    init?(hex: String) {
        var out = Data()
        var chars = Array(hex)
        if chars.count % 2 == 1 { chars.insert("0", at: 0) }
        var i = 0
        while i < chars.count {
            guard let b = UInt8(String(chars[i...i + 1]), radix: 16) else { return nil }
            out.append(b)
            i += 2
        }
        self = out
    }
}
