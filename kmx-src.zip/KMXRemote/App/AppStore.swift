import Foundation
import SwiftUI

struct RemoteItem: Codable, Identifiable, Hashable {
    enum Kind: String, Codable { case googleTV }
    var id = UUID()
    var name: String
    var kind: Kind = .googleTV
    var host: String
    var subtitle: String = "Google TV"
}

/// Everything the app remembers: your remotes and what opens on launch.
final class AppStore: ObservableObject {
    @Published var remotes: [RemoteItem] { didSet { save() } }
    /// "home", "library", or a remote's id.
    @Published var launchTarget: String { didSet { save() } }
    @Published var haptics: Bool { didSet { save() } }
    @Published var lastUsed: UUID? { didSet { save() } }

    private let defaults = UserDefaults.standard
    private var controllers: [UUID: GoogleTVRemote] = [:]

    init() {
        if let data = defaults.data(forKey: "remotes"), let list = try? JSONDecoder().decode([RemoteItem].self, from: data) {
            remotes = list
        } else {
            remotes = []
        }
        launchTarget = defaults.string(forKey: "launchTarget") ?? "home"
        haptics = defaults.object(forKey: "haptics") as? Bool ?? true
        lastUsed = defaults.string(forKey: "lastUsed").flatMap(UUID.init(uuidString:))
    }

    private func save() {
        if let data = try? JSONEncoder().encode(remotes) { defaults.set(data, forKey: "remotes") }
        defaults.set(launchTarget, forKey: "launchTarget")
        defaults.set(haptics, forKey: "haptics")
        defaults.set(lastUsed?.uuidString, forKey: "lastUsed")
    }

    func controller(for item: RemoteItem) -> GoogleTVRemote {
        if let c = controllers[item.id], c.host == item.host { return c }
        let c = GoogleTVRemote(host: item.host)
        controllers[item.id] = c
        return c
    }

    func add(_ item: RemoteItem) {
        remotes.append(item)
        if remotes.count == 1 { lastUsed = item.id }
    }

    func remove(_ item: RemoteItem) {
        controllers[item.id]?.disconnect()
        controllers[item.id] = nil
        remotes.removeAll { $0.id == item.id }
        if launchTarget == item.id.uuidString { launchTarget = "home" }
        if lastUsed == item.id { lastUsed = remotes.first?.id }
    }

    func rename(_ item: RemoteItem, to name: String) {
        guard let i = remotes.firstIndex(where: { $0.id == item.id }) else { return }
        remotes[i].name = name
    }

    func updateHost(_ item: RemoteItem, to host: String) {
        guard let i = remotes.firstIndex(where: { $0.id == item.id }) else { return }
        controllers[item.id]?.disconnect()
        controllers[item.id] = nil
        remotes[i].host = host
    }

    func tap(_ style: UIImpactFeedbackGenerator.FeedbackStyle = .light) {
        guard haptics else { return }
        UIImpactFeedbackGenerator(style: style).impactOccurred()
    }
}
