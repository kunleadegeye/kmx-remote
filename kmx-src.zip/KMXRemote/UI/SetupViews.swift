import SwiftUI

/// Add a TV: pick it from the list (found automatically on Wi‑Fi) or type its address, then pair.
struct AddTVView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var discovery = TVDiscovery()
    @State private var manualIP = ""
    @State private var name = "Living room TV"
    @State private var pairingHost: String?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Add your TV").font(.system(size: 28, weight: .semibold))
                        Text("Make sure the TV is on and your iPhone is on the same Wi‑Fi.")
                            .font(.system(size: 14)).foregroundStyle(Theme.muted)
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        Text("NAME").font(Theme.mono(11)).tracking(1.2).foregroundStyle(Theme.muted)
                        TextField("Living room TV", text: $name)
                            .font(.system(size: 16))
                            .padding(.horizontal, 16).frame(height: 50).card(14)
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("TVS ON YOUR WI‑FI").font(Theme.mono(11)).tracking(1.2).foregroundStyle(Theme.muted)
                            Spacer()
                            if discovery.searching { ProgressView().scaleEffect(0.7) }
                        }
                        if discovery.tvs.isEmpty {
                            Text("Looking for Google TVs…")
                                .font(.system(size: 14)).foregroundStyle(Theme.muted)
                                .frame(maxWidth: .infinity, minHeight: 60).card(18)
                        }
                        ForEach(discovery.tvs) { tv in
                            Button {
                                if let host = tv.host { pairingHost = host }
                            } label: {
                                HStack(spacing: 14) {
                                    DeviceGlyph(size: 44)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(tv.name).font(.system(size: 16, weight: .semibold)).foregroundStyle(Theme.text)
                                        Text(tv.host ?? "Finding address…").font(.system(size: 13)).foregroundStyle(Theme.muted)
                                    }
                                    Spacer()
                                    Image(systemName: "chevron.right").foregroundStyle(Theme.muted)
                                }
                                .padding(14).card(20)
                            }
                            .buttonStyle(KeyPressStyle())
                            .disabled(tv.host == nil)
                        }
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        Text("OR TYPE THE TV'S IP ADDRESS").font(Theme.mono(11)).tracking(1.2).foregroundStyle(Theme.muted)
                        Text("On the TV: Settings › Network & Internet › your Wi‑Fi › IP address")
                            .font(.system(size: 12)).foregroundStyle(Theme.muted)
                        HStack(spacing: 10) {
                            TextField("192.168.1.20", text: $manualIP)
                                .keyboardType(.decimalPad)
                                .font(.system(size: 16, design: .monospaced))
                                .padding(.horizontal, 16).frame(height: 50).card(14)
                            Button("Connect") { pairingHost = manualIP.trimmingCharacters(in: .whitespaces) }
                                .font(.system(size: 15, weight: .semibold))
                                .padding(.horizontal, 18).frame(height: 50)
                                .background(RoundedRectangle(cornerRadius: 14).fill(Theme.signal))
                                .foregroundStyle(Theme.signalText)
                                .disabled(manualIP.split(separator: ".").count != 4)
                        }
                    }
                }
                .padding(20)
            }
            .background(Theme.ground.ignoresSafeArea())
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
            }
        }
        .onAppear { discovery.start() }
        .onDisappear { discovery.stop() }
        .fullScreenCover(item: Binding(get: { pairingHost.map { HostID(host: $0) } }, set: { pairingHost = $0?.host })) { h in
            PairTVView(host: h.host, name: name) { host in
                let item = RemoteItem(name: name.isEmpty ? "TV" : name, host: host, subtitle: "TCL · Google TV")
                store.add(item)
                pairingHost = nil
                dismiss()
            } onCancel: {
                pairingHost = nil
            }
        }
    }
}

struct HostID: Identifiable { let host: String; var id: String { host } }

/// Shows the 6-character code entry while the TV displays its code.
struct PairTVView: View {
    let host: String
    let name: String
    let onPaired: (String) -> Void
    let onCancel: () -> Void
    @StateObject private var pairing: GoogleTVPairing
    @State private var code = ""
    @FocusState private var focused: Bool

    init(host: String, name: String, onPaired: @escaping (String) -> Void, onCancel: @escaping () -> Void) {
        self.host = host
        self.name = name
        self.onPaired = onPaired
        self.onCancel = onCancel
        _pairing = StateObject(wrappedValue: GoogleTVPairing(host: host))
    }

    var body: some View {
        VStack(spacing: 24) {
            HStack {
                Button("Cancel") { pairing.cancel(); onCancel() }
                Spacer()
            }
            Spacer().frame(height: 10)
            DeviceGlyph(size: 72)
            VStack(spacing: 8) {
                Text("Pair with \(name)").font(.system(size: 24, weight: .semibold))
                Text(subtitle).font(.system(size: 15)).foregroundStyle(Theme.muted).multilineTextAlignment(.center)
            }

            if pairing.stage == .waitingForCode || pairing.stage == .verifying || isFailedAfterCode {
                HStack(spacing: 8) {
                    ForEach(0..<6, id: \.self) { i in
                        let chars = Array(code)
                        Text(i < chars.count ? String(chars[i]) : "")
                            .font(.system(size: 28, weight: .semibold, design: .monospaced))
                            .frame(width: 46, height: 58)
                            .background(RoundedRectangle(cornerRadius: 12).fill(Theme.surface))
                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(i == chars.count ? Theme.signal : Theme.line, lineWidth: i == chars.count ? 1.5 : 1))
                    }
                }
                .overlay(
                    TextField("", text: $code)
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled()
                        .keyboardType(.asciiCapable)
                        .focused($focused)
                        .foregroundStyle(.clear)
                        .tint(.clear)
                        .onChange(of: code) { v in
                            let clean = String(v.uppercased().filter { "0123456789ABCDEF".contains($0) }.prefix(6))
                            if clean != v { code = clean }
                            if clean.count == 6 { pairing.submit(code: clean) }
                        }
                )
                .onTapGesture { focused = true }
            }

            if case .failed(let message) = pairing.stage {
                Text(message).font(.system(size: 14)).foregroundStyle(Theme.danger).multilineTextAlignment(.center)
                Button("Try again") {
                    code = ""
                    pairing.start()
                }
                .font(.system(size: 15, weight: .semibold))
                .padding(.horizontal, 22).frame(height: 46)
                .background(Capsule().fill(Theme.signal)).foregroundStyle(Theme.signalText)
            }
            if pairing.stage == .connecting || pairing.stage == .verifying {
                ProgressView()
            }
            Spacer()
        }
        .padding(24)
        .background(Theme.ground.ignoresSafeArea())
        .onAppear { pairing.start() }
        .onChange(of: pairing.stage) { s in
            if s == .waitingForCode { focused = true }
            if s == .paired { onPaired(host) }
        }
    }

    private var isFailedAfterCode: Bool {
        if case .failed = pairing.stage { return code.count == 6 }
        return false
    }

    private var subtitle: String {
        switch pairing.stage {
        case .idle, .connecting: return "Connecting to the TV at \(host)…"
        case .waitingForCode: return "Type the 6‑character code showing on your TV screen."
        case .verifying: return "Checking the code…"
        case .paired: return "Paired!"
        case .failed: return "Something went wrong."
        }
    }
}
