import SwiftUI

enum Theme {
    static let ground = Color(hex: 0x0D0E10)
    static let surface = Color(hex: 0x17191C)
    static let surface2 = Color(hex: 0x202328)
    static let pad = Color(hex: 0x15171A)
    static let line = Color(hex: 0x2A2D33)
    static let text = Color(hex: 0xF2F2F0)
    static let muted = Color(hex: 0x9A9DA3)
    static let faint = Color(hex: 0x6E7178)
    static let signal = Color(hex: 0xFF7A1A)
    static let signalText = Color(hex: 0x160A02)
    static let signalSoft = Color(hex: 0x3A1F0C)
    static let online = Color(hex: 0x4ADE80)
    static let warn = Color(hex: 0xFFC24D)
    static let danger = Color(hex: 0xFF8A8A)

    static func mono(_ size: CGFloat) -> Font { .system(size: size, weight: .medium, design: .monospaced) }
}

extension Color {
    init(hex: UInt32) {
        self.init(red: Double((hex >> 16) & 0xFF) / 255, green: Double((hex >> 8) & 0xFF) / 255, blue: Double(hex & 0xFF) / 255)
    }
}

/// Pressed-state scaling for every key.
struct KeyPressStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.93 : 1)
            .brightness(configuration.isPressed ? 0.08 : 0)
            .animation(.easeOut(duration: 0.08), value: configuration.isPressed)
    }
}

/// Round key (Home, Back, Mute…). `accent` = the orange Signal key.
struct RoundKey: View {
    let icon: String
    var label: String
    var size: CGFloat = 56
    var accent = false
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: size * 0.36, weight: .semibold))
                .frame(width: size, height: size)
                .foregroundStyle(accent ? Theme.signalText : Theme.text)
                .background(Circle().fill(accent ? Theme.signal : Theme.surface))
                .overlay(Circle().stroke(accent ? .clear : Theme.line, lineWidth: 1))
        }
        .buttonStyle(KeyPressStyle())
        .accessibilityLabel(label)
    }
}

/// A button that repeats while held (volume, arrows).
struct RepeatKey<Label: View>: View {
    var interval: Double = 0.15
    var onFire: () -> Void
    @ViewBuilder var label: () -> Label
    @State private var timer: Timer?
    @State private var pressed = false

    var body: some View {
        label()
            .scaleEffect(pressed ? 0.93 : 1)
            .brightness(pressed ? 0.08 : 0)
            .animation(.easeOut(duration: 0.08), value: pressed)
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { _ in
                        guard !pressed else { return }
                        pressed = true
                        onFire()
                        timer = Timer.scheduledTimer(withTimeInterval: 0.45, repeats: false) { _ in
                            let began = Date()
                            timer = Timer.scheduledTimer(withTimeInterval: interval, repeats: true) { t in
                                if !pressed || Date().timeIntervalSince(began) > 8 { t.invalidate(); return }
                                onFire()
                            }
                        }
                    }
                    .onEnded { _ in
                        pressed = false
                        timer?.invalidate()
                        timer = nil
                    }
            )
            .onDisappear {
                // Never leave a key repeating (e.g. volume) if the screen changes mid-press.
                timer?.invalidate()
                timer = nil
                pressed = false
            }
            .accessibilityAddTraits(.isButton)
            .accessibilityAction { onFire() }
    }
}

/// Tall + / − rocker (Volume, Channel).
struct Rocker: View {
    let title: String
    let upIcon: String
    let downIcon: String
    let up: () -> Void
    let down: () -> Void

    var body: some View {
        VStack(spacing: 0) {
            RepeatKey(onFire: up) {
                Image(systemName: upIcon).font(.system(size: 20, weight: .semibold)).frame(maxWidth: .infinity, minHeight: 50)
            }
            .accessibilityLabel("\(title) up")
            Text(title).font(Theme.mono(11)).foregroundStyle(Theme.muted).tracking(1.2)
            RepeatKey(onFire: down) {
                Image(systemName: downIcon).font(.system(size: 20, weight: .semibold)).frame(maxWidth: .infinity, minHeight: 50)
            }
            .accessibilityLabel("\(title) down")
        }
        .foregroundStyle(Theme.text)
        .padding(.vertical, 4)
        .background(RoundedRectangle(cornerRadius: 30).fill(Theme.surface))
        .overlay(RoundedRectangle(cornerRadius: 30).stroke(Theme.line))
    }
}

/// Two-option switch (Trackpad / D‑pad).
struct SegmentedSwitch: View {
    let options: [String]
    @Binding var selection: Int

    var body: some View {
        HStack(spacing: 4) {
            ForEach(options.indices, id: \.self) { i in
                Button {
                    withAnimation(.easeOut(duration: 0.15)) { selection = i }
                } label: {
                    Text(options[i])
                        .font(.system(size: 13, weight: .medium))
                        .frame(maxWidth: .infinity, minHeight: 34)
                        .foregroundStyle(selection == i ? Theme.ground : Color(hex: 0xC9CBCF))
                        .background(RoundedRectangle(cornerRadius: 10).fill(selection == i ? Theme.text : .clear))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(4)
        .background(RoundedRectangle(cornerRadius: 14).fill(Theme.surface))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Theme.line))
    }
}

/// Connected / Searching / Offline pill.
struct StatusPill: View {
    let status: GoogleTVRemote.Status

    var body: some View {
        HStack(spacing: 6) {
            Circle().fill(color).frame(width: 6, height: 6)
            Text(text).font(.system(size: 12))
        }
        .foregroundStyle(color)
    }

    private var color: Color {
        switch status {
        case .connected: return Theme.online
        case .connecting, .disconnected: return Theme.warn
        case .needsPairing, .unreachable: return Theme.danger
        }
    }

    private var text: String {
        switch status {
        case .connected: return "Connected · Wi‑Fi"
        case .connecting: return "Connecting…"
        case .disconnected: return "Reconnecting…"
        case .needsPairing: return "Needs pairing"
        case .unreachable: return "Not reachable"
        }
    }
}

/// Icon tile used on remote cards.
struct DeviceGlyph: View {
    var size: CGFloat = 44
    var body: some View {
        Image(systemName: "tv")
            .font(.system(size: size * 0.45, weight: .medium))
            .foregroundStyle(Color(hex: 0xFF8A3D))
            .frame(width: size, height: size)
            .background(RoundedRectangle(cornerRadius: size * 0.3).fill(Theme.signalSoft))
    }
}

/// Header: back · name + status · power.
struct RemoteHeader: View {
    let title: String
    let status: GoogleTVRemote.Status
    let onBack: () -> Void
    let onPower: () -> Void

    var body: some View {
        HStack {
            RoundKey(icon: "chevron.left", label: "Back to library", size: 44, action: onBack)
            Spacer()
            VStack(spacing: 2) {
                Text(title).font(.system(size: 16, weight: .semibold)).lineLimit(1)
                StatusPill(status: status)
            }
            Spacer()
            RoundKey(icon: "power", label: "Power", size: 44, accent: true, action: onPower)
        }
    }
}

struct CardBackground: ViewModifier {
    var radius: CGFloat = 24
    func body(content: Content) -> some View {
        content
            .background(RoundedRectangle(cornerRadius: radius).fill(Theme.surface))
            .overlay(RoundedRectangle(cornerRadius: radius).stroke(Theme.line))
    }
}

extension View {
    func card(_ radius: CGFloat = 24) -> some View { modifier(CardBackground(radius: radius)) }
}
