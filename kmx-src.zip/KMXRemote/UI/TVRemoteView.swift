import SwiftUI

struct TVRemoteView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    let item: RemoteItem
    @ObservedObject var remote: GoogleTVRemote

    @AppStorage("padMode") private var padMode = 0
    @State private var showKeyboard = false
    @State private var showVoice = false
    @State private var showPairing = false
    @State private var showApps = false

    init(item: RemoteItem, remote: GoogleTVRemote) {
        self.item = item
        self.remote = remote
    }

    var body: some View {
        VStack(spacing: 14) {
            RemoteHeader(title: item.name, status: remote.status, onBack: { dismiss() }) {
                key(.power, .medium)
            }

            HStack {
                Spacer()
                SegmentedSwitch(options: ["Trackpad", "D‑pad", "Pointer"], selection: $padMode).frame(width: 270)
                Spacer()
            }
            .overlay(alignment: .trailing) {
                Button { showApps = true } label: {
                    Image(systemName: "square.grid.2x2").font(.system(size: 17, weight: .semibold))
                        .frame(width: 44, height: 44).foregroundStyle(Theme.text)
                }
                .accessibilityLabel("Apps")
            }

            ZStack {
                switch padMode {
                case 1:
                    DPadView { k in key(k) }
                case 2:
                    PointerPadView(link: store.pointer(for: item))
                default:
                    TrackpadView(step: 38 / CGFloat(store.pointerSpeed)) { k in key(k) }
                }
                connectionOverlay
            }
            .frame(maxHeight: .infinity)

            HStack {
                RoundKey(icon: "arrow.uturn.backward", label: "Back") { key(.back) }
                Spacer()
                RoundKey(icon: "house", label: "Home") { key(.home) }
                Spacer()
                RoundKey(icon: "mic.fill", label: "Voice search", size: 72, accent: true) {
                    store.tap(.medium)
                    showVoice = true
                }
                Spacer()
                RoundKey(icon: "keyboard", label: "Keyboard") {
                    store.tap()
                    showKeyboard = true
                }
                Spacer()
                RoundKey(icon: "playpause.fill", label: "Play or pause") { key(.playPause) }
            }

            HStack(spacing: 10) {
                Rocker(title: "VOL", upIcon: "plus", downIcon: "minus", up: { key(.volumeUp) }, down: { key(.volumeDown) })
                VStack(spacing: 10) {
                    smallKey("speaker.slash", "Mute") { key(.mute) }
                    smallKey("rectangle.portrait.and.arrow.right", "Input source") { key(.input) }
                }
                .frame(width: 64)
                Rocker(title: "CH", upIcon: "chevron.up", downIcon: "chevron.down", up: { key(.channelUp) }, down: { key(.channelDown) })
            }
            .frame(height: 120)
        }
        .padding(.horizontal, 20)
        .padding(.top, 8)
        .padding(.bottom, 12)
        .background(Theme.ground.ignoresSafeArea())
        .navigationBarHidden(true)
        .onAppear {
            store.lastUsed = item.id
            remote.connect()
        }
        .onChange(of: scenePhase) { phase in
            if phase == .active { remote.connect() }
            if phase == .background { remote.disconnect() }
        }
        .onChange(of: remote.status) { s in
            if s == .needsPairing { showPairing = true }
        }
        .sheet(isPresented: $showKeyboard) {
            TVKeyboardSheet(remote: remote).environmentObject(store)
                .presentationDetents([.height(250)])
                .presentationDragIndicator(.visible)
        }
        .sheet(isPresented: $showVoice) {
            VoiceSheet(remote: remote, openKeyboard: {
                showVoice = false
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { showKeyboard = true }
            })
            .environmentObject(store)
            .presentationDetents([.height(420)])
        }
        .sheet(isPresented: $showApps) {
            AppsSheet(remote: remote).environmentObject(store)
                .presentationDetents([.medium])
        }
        .fullScreenCover(isPresented: $showPairing) {
            PairTVView(host: item.host, name: item.name) { _ in
                showPairing = false
                remote.disconnect()
                remote.connect()
            } onCancel: {
                showPairing = false
            }
        }
    }

    @ViewBuilder private var connectionOverlay: some View {
        switch remote.status {
        case .unreachable(let message):
            VStack(spacing: 12) {
                Image(systemName: "wifi.exclamationmark").font(.system(size: 28)).foregroundStyle(Theme.danger)
                Text(message).font(.system(size: 14)).multilineTextAlignment(.center).foregroundStyle(Theme.text)
                Button("Try again") { remote.disconnect(); remote.connect() }
                    .font(.system(size: 15, weight: .semibold))
                    .padding(.horizontal, 20).frame(height: 44)
                    .background(Capsule().fill(Theme.signal)).foregroundStyle(Theme.signalText)
            }
            .padding(24)
            .frame(maxWidth: .infinity)
            .background(RoundedRectangle(cornerRadius: 24).fill(Theme.ground.opacity(0.92)))
            .padding(16)
        case .needsPairing:
            VStack(spacing: 12) {
                Text("This TV needs to be paired again.").font(.system(size: 15)).foregroundStyle(Theme.text)
                Button("Pair now") { showPairing = true }
                    .font(.system(size: 15, weight: .semibold))
                    .padding(.horizontal, 20).frame(height: 44)
                    .background(Capsule().fill(Theme.signal)).foregroundStyle(Theme.signalText)
            }
            .padding(24)
            .background(RoundedRectangle(cornerRadius: 24).fill(Theme.ground.opacity(0.92)))
        default:
            EmptyView()
        }
    }

    private func smallKey(_ icon: String, _ label: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon).font(.system(size: 18, weight: .semibold))
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .foregroundStyle(Theme.text)
                .card(20)
        }
        .buttonStyle(KeyPressStyle())
        .accessibilityLabel(label)
    }

    private func key(_ k: TVKey, _ feel: UIImpactFeedbackGenerator.FeedbackStyle = .light) {
        store.tap(feel)
        remote.press(k)
    }
}

/// Type straight into the TV's search box. Only the change is sent, so letters never repeat,
/// and the phone's delete key deletes on the TV even when the phone's box is empty.
struct TVKeyboardSheet: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var remote: GoogleTVRemote
    /// Invisible marker kept at the start so a backspace on an "empty" box still reaches us.
    private static let mark = "\u{200B}"
    @State private var text = TVKeyboardSheet.mark
    @State private var sent = ""
    @FocusState private var focused: Bool

    private var visible: String { text.replacingOccurrences(of: Self.mark, with: "") }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Typing goes straight into the TV's text box")
                    .font(.system(size: 13)).foregroundStyle(Theme.muted)
                Spacer()
                Button("Done") { dismiss() }.font(.system(size: 15, weight: .semibold))
            }
            HStack(spacing: 10) {
                ZStack(alignment: .leading) {
                    if visible.isEmpty {
                        Text("Type to search on TV")
                            .font(.system(size: 17))
                            .foregroundStyle(Theme.faint)
                            .allowsHitTesting(false)
                    }
                    TextField("", text: $text)
                        .font(.system(size: 17))
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .submitLabel(.search)
                        .focused($focused)
                        .onSubmit {
                            remote.press(.enter)
                            store.tap()
                            focused = true
                        }
                        .onChange(of: text) { newValue in sync(newValue) }
                }
                if !visible.isEmpty {
                    Button { clearAll() } label: {
                        Image(systemName: "xmark.circle.fill").foregroundStyle(Theme.muted)
                    }
                    .accessibilityLabel("Clear")
                }
                Button("Search") {
                    remote.press(.enter)
                    store.tap()
                }
                .font(.system(size: 14, weight: .semibold))
                .padding(.horizontal, 14).frame(height: 38)
                .background(RoundedRectangle(cornerRadius: 12).fill(Theme.signal))
                .foregroundStyle(Theme.signalText)
            }
            .padding(.leading, 16).padding(.trailing, 8)
            .frame(height: 54)
            .background(RoundedRectangle(cornerRadius: 16).fill(Theme.surface))
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(Theme.signal, lineWidth: 1.5))

            HStack(spacing: 10) {
                miniKey("arrow.left", "Left") { remote.press(.left) }
                miniKey("arrow.right", "Right") { remote.press(.right) }
                miniKey("arrow.up", "Up") { remote.press(.up) }
                miniKey("arrow.down", "Down to results") { remote.press(.down) }
                miniKey("return", "Enter") { remote.press(.enter) }
            }
        }
        .padding(20)
        .background(Theme.ground.ignoresSafeArea())
        .onAppear { focused = true }
    }

    /// Sends only what changed since last time: deletes for removed letters, the new letters for added ones.
    private func sync(_ newValue: String) {
        if newValue.isEmpty {
            // Backspace with nothing left on the phone: delete one letter on the TV too.
            remote.press(.del)
            sent = ""
            text = Self.mark
            return
        }
        if !newValue.hasPrefix(Self.mark) {
            text = Self.mark + newValue.replacingOccurrences(of: Self.mark, with: "")
            return
        }
        let now = visible
        let common = zip(sent, now).prefix(while: { $0.0 == $0.1 }).count
        let removed = sent.count - common
        if removed > 0 { remote.deleteBackward(removed) }
        let added = String(now.dropFirst(common))
        if !added.isEmpty { remote.insertText(added) }
        sent = now
    }

    private func clearAll() {
        store.tap()
        remote.deleteBackward(sent.count)
        sent = ""
        text = Self.mark
    }

    private func miniKey(_ icon: String, _ label: String, action: @escaping () -> Void) -> some View {
        Button {
            store.tap()
            action()
        } label: {
            Image(systemName: icon).font(.system(size: 16, weight: .semibold))
                .frame(maxWidth: .infinity, minHeight: 44)
                .foregroundStyle(Theme.text)
                .card(14)
        }
        .buttonStyle(KeyPressStyle())
        .accessibilityLabel(label)
    }
}

/// Tap the mic, speak, tap stop. Audio streams to the TV's voice search when the TV accepts it;
/// the phone also writes down what you said, so you can send it as text if the TV didn't listen.
struct VoiceSheet: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var remote: GoogleTVRemote
    var openKeyboard: () -> Void

    enum Phase { case starting, listening, finished, denied }
    @State private var phase: Phase = .starting
    @State private var tvHears = false
    @State private var heard = ""
    @State private var levels: [CGFloat] = Array(repeating: 0.1, count: 9)
    @State private var capture = VoiceCapture()
    @State private var speech = SpeechTranscriber()
    @State private var autoStop: DispatchWorkItem?
    @State private var closed = false

    var body: some View {
        VStack(spacing: 16) {
            Text(title).font(Theme.mono(11)).tracking(1.6).foregroundStyle(Theme.signal)
            if phase == .starting || phase == .listening {
                HStack(spacing: 6) {
                    ForEach(levels.indices, id: \.self) { i in
                        Capsule().fill(Theme.signal).frame(width: 6, height: 10 + levels[i] * 46)
                    }
                }
                .frame(height: 60)
                .animation(.easeOut(duration: 0.1), value: levels)
            }
            if !heard.isEmpty {
                Text("“\(heard)”")
                    .font(.system(size: 19, weight: .semibold))
                    .multilineTextAlignment(.center)
                    .lineLimit(3)
                    .foregroundStyle(Theme.text)
            }
            Text(message).font(.system(size: 14)).multilineTextAlignment(.center).foregroundStyle(Theme.muted)

            switch phase {
            case .listening, .starting:
                Button { stopListening() } label: {
                    RoundedRectangle(cornerRadius: 5).fill(Theme.signalText).frame(width: 20, height: 20)
                        .frame(width: 76, height: 76)
                        .background(Circle().fill(Theme.signal))
                        .overlay(Circle().stroke(Theme.signalSoft, lineWidth: 6))
                }
                .accessibilityLabel("Stop listening")
            case .finished:
                if heard.isEmpty {
                    HStack(spacing: 10) {
                        wide("Try again", filled: true) { restart() }
                        wide("Keyboard", filled: false) { openKeyboard() }
                    }
                } else {
                    HStack(spacing: 10) {
                        wide("Type on TV", filled: !tvHears) { typeOnTV() }
                        wide("Search YouTube", filled: false) { searchYouTube() }
                    }
                    if tvHears {
                        Button("Done") { dismiss() }.font(.system(size: 15, weight: .semibold))
                    }
                }
            case .denied:
                wide("Use the keyboard instead", filled: true) { openKeyboard() }
            }
        }
        .padding(24)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Theme.ground.ignoresSafeArea())
        .onAppear(perform: start)
        .onDisappear {
            closed = true
            autoStop?.cancel()
            capture.stop()
            speech.cancel()
            remote.endVoice()
        }
    }

    private var title: String {
        switch phase {
        case .starting: return "GETTING READY"
        case .listening: return "LISTENING"
        case .finished: return tvHears ? "SENT TO TV" : "DONE"
        case .denied: return "MICROPHONE OFF"
        }
    }

    private var message: String {
        switch phase {
        case .starting: return "One moment…"
        case .listening:
            return tvHears ? "Speak now, your TV is listening.\nTap stop when you're done." : "Speak now, your phone is listening.\nTap stop when you're done."
        case .finished:
            if heard.isEmpty { return tvHears ? "Sent to your TV." : "I didn't catch that. Try again, or use the keyboard." }
            return tvHears ? "Your TV got it. If it misheard, send the words as text instead."
                           : "Your TV didn't take the voice, so your phone wrote it down. Open a search box on the TV and tap Type on TV, or search YouTube directly."
        case .denied: return "Allow microphone access for KMX Remote in iPhone Settings to use voice."
        }
    }

    private func wide(_ label: String, filled: Bool, action: @escaping () -> Void) -> some View {
        Button {
            store.tap()
            action()
        } label: {
            Text(label)
                .font(.system(size: 15, weight: .semibold))
                .frame(maxWidth: .infinity, minHeight: 48)
                .background(RoundedRectangle(cornerRadius: 14).fill(filled ? Theme.signal : Theme.surface))
                .foregroundStyle(filled ? Theme.signalText : Theme.text)
        }
        .buttonStyle(KeyPressStyle())
    }

    private func start() {
        closed = false
        heard = ""
        phase = .starting
        VoiceCapture.requestPermission { ok in
            guard ok else { phase = .denied; return }
            SpeechTranscriber.requestPermission { _ in
                remote.beginVoice { started in
                    guard !closed else {
                        if started { remote.endVoice() }
                        return
                    }
                    tvHears = started
                    if started {
                        capture.onChunk = { remote.sendVoice($0) }
                    } else {
                        capture.onChunk = nil
                    }
                    let transcriber = speech
                    capture.onBuffer = { transcriber.append($0) }
                    capture.onLevel = { level in
                        levels.removeFirst()
                        levels.append(CGFloat(min(1, level * 3)))
                    }
                    speech.onText = { heard = $0 }
                    speech.start()
                    do {
                        try capture.start()
                        phase = .listening
                        store.tap(.medium)
                        let work = DispatchWorkItem { stopListening() }
                        autoStop = work
                        DispatchQueue.main.asyncAfter(deadline: .now() + 12, execute: work)
                    } catch {
                        remote.endVoice()
                        speech.cancel()
                        phase = .finished
                    }
                }
            }
        }
    }

    private func stopListening() {
        autoStop?.cancel()
        capture.stop()
        speech.stop()
        remote.endVoice()
        phase = .finished
    }

    private func restart() {
        capture = VoiceCapture()
        speech = SpeechTranscriber()
        start()
    }

    private func typeOnTV() {
        let words = heard
        remote.insertText(words)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { remote.press(.enter) }
        dismiss()
    }

    private func searchYouTube() {
        let q = heard.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? heard
        remote.openApp("https://www.youtube.com/results?search_query=\(q)")
        dismiss()
    }
}

/// Quick app launcher.
struct AppsSheet: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var remote: GoogleTVRemote

    private let apps: [(String, String)] = [
        ("YouTube", "https://www.youtube.com"),
        ("Netflix", "https://www.netflix.com/title"),
        ("Prime Video", "https://app.primevideo.com"),
        ("Disney+", "https://www.disneyplus.com"),
        ("Spotify", "spotify://"),
        ("Showmax", "https://www.showmax.com"),
    ]

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Open on TV").font(.system(size: 20, weight: .semibold))
            LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
                ForEach(apps, id: \.0) { app in
                    Button {
                        store.tap()
                        remote.openApp(app.1)
                        dismiss()
                    } label: {
                        Text(app.0).font(.system(size: 15, weight: .medium))
                            .frame(maxWidth: .infinity, minHeight: 54)
                            .foregroundStyle(Theme.text)
                            .card(16)
                    }
                    .buttonStyle(KeyPressStyle())
                }
            }
            HStack(spacing: 10) {
                quick("gearshape", "TV settings") { remote.press(.settings) }
                quick("list.bullet.rectangle", "Guide") { remote.press(.guide) }
                quick("info.circle", "Info") { remote.press(.info) }
                quick("line.3.horizontal", "Menu") { remote.press(.menu) }
            }
            Spacer()
        }
        .padding(20)
        .background(Theme.ground.ignoresSafeArea())
    }

    private func quick(_ icon: String, _ label: String, action: @escaping () -> Void) -> some View {
        Button {
            store.tap()
            action()
            dismiss()
        } label: {
            VStack(spacing: 6) {
                Image(systemName: icon).font(.system(size: 18))
                Text(label).font(.system(size: 11))
            }
            .frame(maxWidth: .infinity, minHeight: 64)
            .foregroundStyle(Theme.text)
            .card(16)
        }
        .buttonStyle(KeyPressStyle())
    }
}
