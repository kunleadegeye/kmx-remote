import SwiftUI

/// Swipe surface: each step of travel moves the TV's focus one item. Tap = OK.
/// Arrows along the edges can be tapped or held to keep moving.
struct TrackpadView: View {
    let onKey: (TVKey) -> Void
    var step: CGFloat = 38

    @State private var anchor: CGPoint?
    @State private var startTime = Date()
    @State private var travelled: CGFloat = 0
    @State private var touch: CGPoint?
    @State private var flash: TVKey?

    var body: some View {
        GeometryReader { geo in
            ZStack {
                RoundedRectangle(cornerRadius: 32).fill(Theme.pad)
                RoundedRectangle(cornerRadius: 32).stroke(Theme.line)

                if let touch {
                    Circle().fill(Theme.signal.opacity(0.22)).frame(width: 64, height: 64).position(touch)
                }

                VStack(spacing: 10) {
                    ZStack {
                        Circle().stroke(Color(hex: 0x33373E), lineWidth: 1.5).frame(width: 56, height: 56)
                        Circle().fill(flash == .center ? Theme.text : Theme.signal).frame(width: 14, height: 14)
                    }
                    Text("Swipe to move · Tap to select\nHold an edge arrow to keep moving")
                        .font(.system(size: 13))
                        .multilineTextAlignment(.center)
                        .foregroundStyle(Theme.faint)
                }
                .allowsHitTesting(false)

                surfaceGesture

                edgeArrow(.up, "chevron.up").position(x: geo.size.width / 2, y: 24)
                edgeArrow(.down, "chevron.down").position(x: geo.size.width / 2, y: geo.size.height - 24)
                edgeArrow(.left, "chevron.left").position(x: 24, y: geo.size.height / 2)
                edgeArrow(.right, "chevron.right").position(x: geo.size.width - 24, y: geo.size.height / 2)
            }
        }
    }

    private var surfaceGesture: some View {
        Color.clear
            .contentShape(RoundedRectangle(cornerRadius: 32))
            .gesture(
                DragGesture(minimumDistance: 0, coordinateSpace: .local)
                    .onChanged { value in
                        touch = value.location
                        if anchor == nil {
                            anchor = value.startLocation
                            startTime = Date()
                            travelled = 0
                        }
                        guard var a = anchor else { return }
                        var dx = value.location.x - a.x
                        var dy = value.location.y - a.y
                        // Emit one key per step along the dominant axis; keep the remainder.
                        while abs(dx) >= step || abs(dy) >= step {
                            if abs(dx) >= abs(dy) {
                                let key: TVKey = dx > 0 ? .right : .left
                                send(key)
                                a.x += dx > 0 ? step : -step
                                a.y = value.location.y
                            } else {
                                let key: TVKey = dy > 0 ? .down : .up
                                send(key)
                                a.y += dy > 0 ? step : -step
                                a.x = value.location.x
                            }
                            travelled += step
                            dx = value.location.x - a.x
                            dy = value.location.y - a.y
                        }
                        anchor = a
                    }
                    .onEnded { value in
                        let moved = hypot(value.translation.width, value.translation.height)
                        if travelled == 0 && moved < 12 && Date().timeIntervalSince(startTime) < 0.4 {
                            send(.center)
                        }
                        anchor = nil
                        withAnimation(.easeOut(duration: 0.2)) { touch = nil }
                    }
            )
            .accessibilityLabel("Trackpad")
            .accessibilityAddTraits(.allowsDirectInteraction)
    }

    private func edgeArrow(_ key: TVKey, _ icon: String) -> some View {
        RepeatKey(interval: 0.18, onFire: { send(key) }) {
            Image(systemName: icon)
                .font(.system(size: 20, weight: .semibold))
                .foregroundStyle(flash == key ? Theme.signal : Theme.faint)
                .frame(width: 56, height: 48)
        }
        .accessibilityLabel(String(describing: key).capitalized)
    }

    private func send(_ key: TVKey) {
        onKey(key)
        flash = key
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { if flash == key { flash = nil } }
    }
}

/// Classic round D‑pad with OK in the middle.
struct DPadView: View {
    let onKey: (TVKey) -> Void
    @State private var lit: TVKey?

    var body: some View {
        GeometryReader { geo in
            let s = min(geo.size.width, geo.size.height)
            ZStack {
                Circle().fill(Theme.surface)
                Circle().stroke(Theme.line)
                arrow(.up, "chevron.up").offset(y: -s * 0.36)
                arrow(.down, "chevron.down").offset(y: s * 0.36)
                arrow(.left, "chevron.left").offset(x: -s * 0.36)
                arrow(.right, "chevron.right").offset(x: s * 0.36)
                Button { fire(.center) } label: {
                    Text("OK")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(Theme.text)
                        .frame(width: s * 0.38, height: s * 0.38)
                        .background(Circle().fill(Theme.surface2))
                        .overlay(Circle().stroke(Color(hex: 0x33373E)))
                }
                .buttonStyle(KeyPressStyle())
            }
            .frame(width: s, height: s)
            .position(x: geo.size.width / 2, y: geo.size.height / 2)
        }
    }

    private func arrow(_ key: TVKey, _ icon: String) -> some View {
        RepeatKey(interval: 0.18, onFire: { fire(key) }) {
            Image(systemName: icon)
                .font(.system(size: 24, weight: .semibold))
                .foregroundStyle(lit == key ? Theme.signal : Color(hex: 0xC9CBCF))
                .frame(width: 80, height: 70)
        }
        .accessibilityLabel(String(describing: key).capitalized)
    }

    private func fire(_ key: TVKey) {
        onKey(key)
        lit = key
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { if lit == key { lit = nil } }
    }
}
