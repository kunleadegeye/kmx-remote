import SwiftUI

/// Moves a real mouse pointer on the TV. Slide a finger, or switch on Motion and point the phone.
/// Needs the KMX Pointer helper on the TV (one-time setup shown here).
struct PointerPadView: View {
    @EnvironmentObject var store: AppStore
    @ObservedObject var link: PointerLink
    @StateObject private var server = HelperServer()
    @State private var motion = MotionPointer()
    @State private var motionOn = false
    @State private var last: CGPoint?
    @State private var startTime = Date()
    @State private var travelled: CGFloat = 0
    @State private var touch: CGPoint?
    @State private var lastScroll: CGFloat?
    @State private var waited = false
    @State private var longWork: DispatchWorkItem?

    init(link: PointerLink) {
        self.link = link
    }

    var body: some View {
        ZStack {
            if link.helperFound {
                pad
            } else if waited {
                setup
            } else {
                RoundedRectangle(cornerRadius: 32).fill(Theme.pad)
                    .overlay(ProgressView().tint(Theme.signal))
            }
        }
        .onAppear {
            link.start()
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) { waited = true }
        }
        .onDisappear {
            stopMotion()
            server.stop()
            link.stop()
        }
        .onChange(of: link.helperFound) { found in
            if found { server.stop() } else { stopMotion() }
        }
    }

    // MARK: Pad

    private var pad: some View {
        ZStack(alignment: .trailing) {
            RoundedRectangle(cornerRadius: 32).fill(Theme.pad)
            RoundedRectangle(cornerRadius: 32).stroke(motionOn ? Theme.signal : Theme.line, lineWidth: motionOn ? 1.5 : 1)

            if let touch {
                Circle().fill(Theme.signal.opacity(0.22)).frame(width: 64, height: 64).position(touch)
            }

            VStack(spacing: 10) {
                Image(systemName: motionOn ? "gyroscope" : "cursorarrow.motionlines")
                    .font(.system(size: 26))
                    .foregroundStyle(Theme.signal)
                Text(motionOn ? "Point the phone to move\nTap anywhere here to click" : "Slide to move · Tap to click\nHold to long‑press · Right strip scrolls")
                    .font(.system(size: 13))
                    .multilineTextAlignment(.center)
                    .foregroundStyle(Theme.faint)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .allowsHitTesting(false)

            surface

            scrollStrip
                .frame(width: 54)
                .padding(.vertical, 16)
                .padding(.trailing, 10)
        }
        .overlay(alignment: .bottomLeading) {
            HStack(spacing: 8) {
                pill(motionOn ? "Motion on" : "Motion", icon: "gyroscope", on: motionOn) { toggleMotion() }
                pill("Centre", icon: "scope", on: false) {
                    store.tap()
                    link.center()
                }
            }
            .padding(14)
        }
    }

    private var surface: some View {
        Color.clear
            .contentShape(RoundedRectangle(cornerRadius: 32))
            .gesture(
                DragGesture(minimumDistance: 0, coordinateSpace: .local)
                    .onChanged { v in
                        touch = v.location
                        guard let l = last else {
                            last = v.location
                            startTime = Date()
                            travelled = 0
                            let work = DispatchWorkItem {
                                if travelled < 8 {
                                    store.tap(.medium)
                                    link.longClick()
                                    travelled = 9999
                                }
                            }
                            longWork = work
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6, execute: work)
                            return
                        }
                        let dx = v.location.x - l.x
                        let dy = v.location.y - l.y
                        last = v.location
                        travelled += hypot(dx, dy)
                        if travelled > 8 { longWork?.cancel() }
                        guard !motionOn else { return }
                        // Faster swipes travel further, slow ones stay precise.
                        let speed = Double(hypot(dx, dy))
                        let accel = 1 + min(speed / 10, 2.5)
                        let k = 2.0 * store.pointerSpeed * accel
                        link.move(dx: Double(dx) * k, dy: Double(dy) * k)
                    }
                    .onEnded { _ in
                        longWork?.cancel()
                        if travelled < 8 && Date().timeIntervalSince(startTime) < 0.45 {
                            store.tap()
                            link.click()
                        }
                        last = nil
                        withAnimation(.easeOut(duration: 0.2)) { touch = nil }
                    }
            )
            .accessibilityLabel("Pointer pad")
            .accessibilityAddTraits(.allowsDirectInteraction)
    }

    private var scrollStrip: some View {
        RoundedRectangle(cornerRadius: 22)
            .fill(Theme.surface)
            .overlay(RoundedRectangle(cornerRadius: 22).stroke(Theme.line))
            .overlay(
                VStack {
                    Image(systemName: "chevron.up")
                    Spacer()
                    Image(systemName: "arrow.up.and.down").font(.system(size: 13))
                    Spacer()
                    Image(systemName: "chevron.down")
                }
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(Theme.faint)
                .padding(.vertical, 14)
            )
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { v in
                        let y = v.location.y
                        if let ls = lastScroll {
                            let d = Double(y - ls) * 4 * store.scrollSpeed * (store.invertScroll ? -1 : 1)
                            link.scroll(dy: d)
                        }
                        lastScroll = y
                    }
                    .onEnded { _ in lastScroll = nil }
            )
            .accessibilityLabel("Scroll")
    }

    private func pill(_ title: String, icon: String, on: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: icon)
                .font(.system(size: 13, weight: .semibold))
                .padding(.horizontal, 12)
                .frame(height: 36)
                .background(Capsule().fill(on ? Theme.signal : Theme.surface2))
                .foregroundStyle(on ? Theme.signalText : Theme.text)
        }
        .buttonStyle(KeyPressStyle())
    }

    private func toggleMotion() {
        store.tap()
        if motionOn {
            stopMotion()
        } else {
            motion.sensitivity = store.motionSpeed
            motion.onMove = { dx, dy in link.move(dx: dx, dy: dy) }
            motion.start()
            motionOn = true
            link.center()
        }
    }

    private func stopMotion() {
        motion.stop()
        motionOn = false
    }

    // MARK: One-time setup

    private var setup: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                Text("ONE-TIME TV SETUP").font(Theme.mono(11)).tracking(1.4).foregroundStyle(Theme.signal)
                Text("The pointer needs the small KMX Pointer helper on your TV.")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(Theme.text)
                step(1, "On the TV, open the Play Store and install Downloader (by AFTVnews).")
                if let address = server.address {
                    step(2, "Open Downloader, type this address and press Go. Keep this screen open on your phone while it downloads.")
                    Text(address)
                        .font(.system(size: 19, weight: .bold, design: .monospaced))
                        .foregroundStyle(Theme.signal)
                        .textSelection(.enabled)
                        .padding(.leading, 34)
                } else {
                    step(2, server.problem ?? "Getting the download ready…")
                }
                step(3, "Choose Install. If the TV asks, allow Downloader to install apps, then press Install again.")
                step(4, "Open KMX Pointer on the TV, press Turn on, and switch on KMX Pointer in the list.")
                Button {
                    store.tap()
                    link.refresh()
                } label: {
                    Text("I've done this, check again")
                        .font(.system(size: 15, weight: .semibold))
                        .frame(maxWidth: .infinity, minHeight: 48)
                        .background(RoundedRectangle(cornerRadius: 14).fill(Theme.signal))
                        .foregroundStyle(Theme.signalText)
                }
                .buttonStyle(KeyPressStyle())
                .padding(.top, 4)
            }
            .padding(18)
        }
        .card(28)
        .onAppear { server.start() }
    }

    private func step(_ n: Int, _ text: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Text("\(n)")
                .font(.system(size: 13, weight: .bold))
                .frame(width: 22, height: 22)
                .background(Circle().fill(Theme.signalSoft))
                .foregroundStyle(Theme.signal)
            Text(text)
                .font(.system(size: 14))
                .foregroundStyle(Theme.text)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}
