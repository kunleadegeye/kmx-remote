import SwiftUI

enum Tab: Hashable { case home, library, settings }

struct RootView: View {
    @EnvironmentObject var store: AppStore
    @State private var tab: Tab = .home
    @State private var path: [RemoteItem] = []
    @State private var didLaunch = false

    var body: some View {
        NavigationStack(path: $path) {
            ZStack(alignment: .bottom) {
                Group {
                    switch tab {
                    case .home: HomeView(open: open, goLibrary: { tab = .library })
                    case .library: LibraryView(open: open)
                    case .settings: SettingsView()
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                BottomBar(tab: $tab)
            }
            .background(Theme.ground.ignoresSafeArea())
            .navigationBarHidden(true)
            .navigationDestination(for: RemoteItem.self) { item in
                TVRemoteView(item: item, remote: store.controller(for: item))
            }
        }
        .onAppear(perform: applyLaunchTarget)
    }

    private func open(_ item: RemoteItem) {
        store.tap()
        path = [item]
    }

    private func applyLaunchTarget() {
        guard !didLaunch else { return }
        didLaunch = true
        switch store.launchTarget {
        case "home": tab = .home
        case "library": tab = .library
        default:
            if let item = store.remotes.first(where: { $0.id.uuidString == store.launchTarget }) {
                tab = .library
                path = [item]
            }
        }
    }
}

struct BottomBar: View {
    @EnvironmentObject var store: AppStore
    @Binding var tab: Tab

    var body: some View {
        HStack {
            item(.home, "house", "Home")
            item(.library, "square.grid.2x2", "Library")
            item(.settings, "slider.horizontal.3", "Settings")
        }
        .frame(height: 64)
        .background(Capsule().fill(Color(hex: 0x1C1E22)))
        .overlay(Capsule().stroke(Theme.line))
        .padding(.horizontal, 20)
        .padding(.bottom, 8)
    }

    private func item(_ t: Tab, _ icon: String, _ label: String) -> some View {
        Button {
            store.tap()
            tab = t
        } label: {
            VStack(spacing: 3) {
                Image(systemName: icon).font(.system(size: 19, weight: .medium))
                Text(label).font(.system(size: 11))
            }
            .foregroundStyle(tab == t ? Theme.text : Color(hex: 0x8A8D93))
            .frame(maxWidth: .infinity, minHeight: 56)
        }
        .buttonStyle(.plain)
    }
}

struct HomeView: View {
    @EnvironmentObject var store: AppStore
    let open: (RemoteItem) -> Void
    let goLibrary: () -> Void
    @State private var adding = false

    private var greeting: String {
        let h = Calendar.current.component(.hour, from: Date())
        return h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening"
    }

    private var lastUsed: RemoteItem? {
        store.remotes.first { $0.id == store.lastUsed } ?? store.remotes.first
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("KMX REMOTE").font(Theme.mono(12)).tracking(1.7).foregroundStyle(Theme.muted)
                    Text(greeting).font(.system(size: 30, weight: .semibold))
                }
                .padding(.top, 12)

                if let item = lastUsed {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Last used").font(.system(size: 13)).foregroundStyle(Theme.muted)
                        LastUsedCard(item: item, remote: store.controller(for: item), open: { open(item) })
                    }
                } else {
                    EmptyHome(add: { adding = true })
                }

                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text("Your remotes").font(.system(size: 13)).foregroundStyle(Theme.muted)
                        Spacer()
                        Button("See library", action: goLibrary).font(.system(size: 13))
                    }
                    LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                        ForEach(store.remotes) { item in
                            Button { open(item) } label: { RemoteTile(item: item) }
                                .buttonStyle(KeyPressStyle())
                        }
                        Button { adding = true } label: {
                            VStack(spacing: 8) {
                                Image(systemName: "plus").font(.system(size: 22))
                                Text("Add a remote").font(.system(size: 14))
                            }
                            .foregroundStyle(Theme.muted)
                            .frame(maxWidth: .infinity, minHeight: 150)
                            .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color(hex: 0x33373E), style: StrokeStyle(lineWidth: 1.5, dash: [6, 5])))
                        }
                        .buttonStyle(KeyPressStyle())
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 100)
        }
        .sheet(isPresented: $adding) { AddTVView().environmentObject(store) }
    }
}

struct EmptyHome: View {
    let add: () -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            DeviceGlyph(size: 52)
            Text("Add your TV to get started").font(.system(size: 20, weight: .semibold))
            Text("KMX Remote finds Google TVs on your Wi‑Fi. You'll type a short code from the TV once.")
                .font(.system(size: 14)).foregroundStyle(Theme.muted)
            Button(action: add) {
                Text("Add TV").font(.system(size: 16, weight: .semibold))
                    .frame(maxWidth: .infinity, minHeight: 50)
                    .background(RoundedRectangle(cornerRadius: 16).fill(Theme.signal))
                    .foregroundStyle(Theme.signalText)
            }
            .buttonStyle(KeyPressStyle())
        }
        .padding(20)
        .card(28)
    }
}

struct LastUsedCard: View {
    @EnvironmentObject var store: AppStore
    let item: RemoteItem
    @ObservedObject var remote: GoogleTVRemote
    let open: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Button(action: open) {
                HStack(spacing: 12) {
                    DeviceGlyph(size: 44)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(item.name).font(.system(size: 17, weight: .semibold)).foregroundStyle(Theme.text)
                        Text(item.subtitle).font(.system(size: 13)).foregroundStyle(Theme.muted)
                    }
                    Spacer()
                    Text("OPEN").font(Theme.mono(12)).foregroundStyle(Color(hex: 0xFF8A3D))
                        .padding(.horizontal, 10).padding(.vertical, 6)
                        .background(Capsule().fill(Theme.signalSoft))
                }
            }
            .buttonStyle(.plain)
            HStack(spacing: 10) {
                RoundKey(icon: "speaker.minus", label: "Volume down", size: 52) { press(.volumeDown) }
                RoundKey(icon: "speaker.plus", label: "Volume up", size: 52) { press(.volumeUp) }
                RoundKey(icon: "speaker.slash", label: "Mute", size: 52) { press(.mute) }
                Spacer()
                RoundKey(icon: "power", label: "Power", size: 52, accent: true) { press(.power) }
            }
        }
        .padding(20)
        .card(28)
        .onAppear { remote.connect() }
    }

    private func press(_ k: TVKey) {
        store.tap()
        remote.press(k)
    }
}

struct RemoteTile: View {
    let item: RemoteItem
    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                DeviceGlyph(size: 40)
                Spacer()
            }
            Spacer()
            VStack(alignment: .leading, spacing: 2) {
                Text(item.name).font(.system(size: 16, weight: .semibold)).foregroundStyle(Theme.text).lineLimit(1)
                Text(item.subtitle).font(.system(size: 12)).foregroundStyle(Theme.muted).lineLimit(1)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, minHeight: 150, alignment: .leading)
        .card(24)
    }
}

struct LibraryView: View {
    @EnvironmentObject var store: AppStore
    let open: (RemoteItem) -> Void
    @State private var query = ""
    @State private var adding = false
    @State private var renaming: RemoteItem?
    @State private var newName = ""
    @State private var changingIP: RemoteItem?
    @State private var newIP = ""

    private var filtered: [RemoteItem] {
        query.isEmpty ? store.remotes : store.remotes.filter { $0.name.localizedCaseInsensitiveContains(query) }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                HStack {
                    Text("Library").font(.system(size: 30, weight: .semibold))
                    Spacer()
                    RoundKey(icon: "plus", label: "Add a remote", size: 44, accent: true) { adding = true }
                }
                .padding(.top, 12)

                HStack(spacing: 10) {
                    Image(systemName: "magnifyingglass").foregroundStyle(Color(hex: 0x8A8D93))
                    TextField("Search remotes", text: $query).font(.system(size: 15))
                }
                .padding(.horizontal, 14).frame(height: 46).card(14)

                if store.remotes.isEmpty {
                    Text("No remotes yet. Tap + to add your TV.")
                        .font(.system(size: 14)).foregroundStyle(Theme.muted)
                        .frame(maxWidth: .infinity, minHeight: 80).card(20)
                }

                ForEach(filtered) { item in
                    HStack(spacing: 14) {
                        Button { open(item) } label: {
                            HStack(spacing: 14) {
                                DeviceGlyph(size: 52)
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(item.name).font(.system(size: 16, weight: .semibold)).foregroundStyle(Theme.text)
                                    Text("\(item.subtitle) · \(item.host)").font(.system(size: 13)).foregroundStyle(Theme.muted)
                                    if store.launchTarget == item.id.uuidString {
                                        Text("OPENS ON LAUNCH").font(Theme.mono(11)).tracking(0.6).foregroundStyle(Color(hex: 0xFF8A3D))
                                    }
                                }
                                Spacer(minLength: 0)
                            }
                        }
                        .buttonStyle(.plain)
                        Menu {
                            Button {
                                store.launchTarget = store.launchTarget == item.id.uuidString ? "home" : item.id.uuidString
                            } label: {
                                Label(store.launchTarget == item.id.uuidString ? "Stop opening on launch" : "Open when app starts", systemImage: "bolt")
                            }
                            Button { newName = item.name; renaming = item } label: { Label("Rename", systemImage: "pencil") }
                            Button { newIP = item.host; changingIP = item } label: { Label("Change TV address", systemImage: "network") }
                            Button(role: .destructive) { store.remove(item) } label: { Label("Remove", systemImage: "trash") }
                        } label: {
                            Image(systemName: "ellipsis").font(.system(size: 18, weight: .semibold))
                                .foregroundStyle(Theme.muted).frame(width: 44, height: 44)
                        }
                        .accessibilityLabel("More options for \(item.name)")
                    }
                    .padding(14)
                    .card(22)
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 100)
        }
        .sheet(isPresented: $adding) { AddTVView().environmentObject(store) }
        .alert("Rename", isPresented: Binding(get: { renaming != nil }, set: { if !$0 { renaming = nil } })) {
            TextField("Name", text: $newName)
            Button("Save") { if let r = renaming { store.rename(r, to: newName) }; renaming = nil }
            Button("Cancel", role: .cancel) { renaming = nil }
        }
        .alert("TV address", isPresented: Binding(get: { changingIP != nil }, set: { if !$0 { changingIP = nil } })) {
            TextField("192.168.1.20", text: $newIP).keyboardType(.decimalPad)
            Button("Save") { if let r = changingIP { store.updateHost(r, to: newIP) }; changingIP = nil }
            Button("Cancel", role: .cancel) { changingIP = nil }
        } message: {
            Text("Use this if your router gave the TV a new address.")
        }
    }
}

struct SettingsView: View {
    @EnvironmentObject var store: AppStore

    private var options: [(id: String, label: String, sub: String)] {
        [("home", "Home", "Last used remote and your remotes"), ("library", "Library", "All your remotes")]
            + store.remotes.map { ($0.id.uuidString, $0.name, "Open straight to this remote") }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Settings").font(.system(size: 30, weight: .semibold)).padding(.top, 12)

                VStack(alignment: .leading, spacing: 8) {
                    Text("WHEN THE APP OPENS, SHOW").font(Theme.mono(11)).tracking(1.3).foregroundStyle(Theme.muted)
                    VStack(spacing: 0) {
                        ForEach(options, id: \.id) { o in
                            Button {
                                store.tap()
                                store.launchTarget = o.id
                            } label: {
                                HStack(spacing: 14) {
                                    ZStack {
                                        Circle().stroke(store.launchTarget == o.id ? Theme.signal : Color(hex: 0x4A4D53), lineWidth: 2).frame(width: 22, height: 22)
                                        if store.launchTarget == o.id { Circle().fill(Theme.signal).frame(width: 10, height: 10) }
                                    }
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(o.label).font(.system(size: 15, weight: .medium)).foregroundStyle(Theme.text)
                                        Text(o.sub).font(.system(size: 12)).foregroundStyle(Theme.muted)
                                    }
                                    Spacer()
                                }
                                .padding(.horizontal, 16).frame(minHeight: 62)
                            }
                            .buttonStyle(.plain)
                            .accessibilityAddTraits(store.launchTarget == o.id ? .isSelected : [])
                            if o.id != options.last?.id { Divider().overlay(Theme.line) }
                        }
                    }
                    .card(22)
                }

                VStack(alignment: .leading, spacing: 8) {
                    Text("FEEL").font(Theme.mono(11)).tracking(1.3).foregroundStyle(Theme.muted)
                    Toggle("Button vibration", isOn: $store.haptics)
                        .font(.system(size: 15))
                        .padding(.horizontal, 16).frame(minHeight: 58)
                        .card(22)
                }

                VStack(alignment: .leading, spacing: 8) {
                    Text("POINTER & TRACKPAD").font(Theme.mono(11)).tracking(1.3).foregroundStyle(Theme.muted)
                    VStack(spacing: 0) {
                        SpeedRow(title: "Pointer speed", detail: "How far the pointer and trackpad move", value: $store.pointerSpeed)
                        Divider().overlay(Theme.line)
                        SpeedRow(title: "Scroll speed", detail: "How far each scroll moves the page", value: $store.scrollSpeed)
                        Divider().overlay(Theme.line)
                        SpeedRow(title: "Phone-movement sensitivity", detail: "For Motion mode: how much the pointer follows the phone", value: $store.motionSpeed)
                        Divider().overlay(Theme.line)
                        Toggle("Reverse scroll direction", isOn: $store.invertScroll)
                            .font(.system(size: 15))
                            .padding(.horizontal, 16).frame(minHeight: 58)
                        Divider().overlay(Theme.line)
                        Button {
                            store.tap()
                            store.pointerSpeed = 1
                            store.scrollSpeed = 1
                            store.motionSpeed = 1
                            store.invertScroll = false
                        } label: {
                            Text("Reset to normal").font(.system(size: 15)).foregroundStyle(Theme.signal)
                                .frame(maxWidth: .infinity, minHeight: 50)
                        }
                        .buttonStyle(.plain)
                    }
                    .card(22)
                }

                Text("KMX Remote 1.1 · works over your home Wi‑Fi, no internet needed.")
                    .font(.system(size: 12)).foregroundStyle(Theme.muted)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 100)
        }
    }
}

/// Slider row for a speed setting (0.3× to 3×).
struct SpeedRow: View {
    let title: String
    let detail: String
    @Binding var value: Double

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(title).font(.system(size: 15)).foregroundStyle(Theme.text)
                Spacer()
                Text(String(format: "%.1f×", value)).font(Theme.mono(12)).foregroundStyle(Theme.muted)
            }
            Text(detail).font(.system(size: 12)).foregroundStyle(Theme.muted)
            Slider(value: $value, in: 0.3...3, step: 0.1)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }
}
